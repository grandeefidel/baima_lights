<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/taxonomy/core/class-qodeframeworkoptionstaxonomy.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/taxonomy/core/class-qodeframeworkpagetaxonomy.php';
