<?php

include_once LUCENT_CORE_INC_PATH . '/404/helper.php';
include_once LUCENT_CORE_INC_PATH . '/404/dashboard/admin/404-options.php';