<?php

include_once LUCENT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/instagram-list.php';
