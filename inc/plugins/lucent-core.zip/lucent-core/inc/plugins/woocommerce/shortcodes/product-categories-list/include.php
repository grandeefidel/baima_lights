<?php

include_once LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/media-custom-fields.php';
include_once LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/product-categories-list.php';
include_once LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/widget/product-categories-list.php';

foreach ( glob( LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}