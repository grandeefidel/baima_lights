<?php

if ( ! function_exists( 'lucent_core_register_product_for_meta_options' ) ) {
	/**
	 * Function that register product post type for meta box options
	 *
	 * @param array $post_types
	 *
	 * @return array
	 */
	function lucent_core_register_product_for_meta_options( $post_types ) {
		$post_types[] = 'product';
		
		return $post_types;
	}
	
	add_filter( 'qode_framework_filter_meta_box_save', 'lucent_core_register_product_for_meta_options' );
	add_filter( 'qode_framework_filter_meta_box_remove', 'lucent_core_register_product_for_meta_options' );
}

if ( ! function_exists( 'lucent_core_woo_get_global_product' ) ) {
	/**
	 * Function that return global WooCommerce object
	 *
	 * @return object
	 */
	function lucent_core_woo_get_global_product() {
		global $product;
		
		return $product;
	}
}

if ( ! function_exists( 'lucent_core_woo_set_admin_options_map_position' ) ) {
	/**
	 * Function that set dashboard admin options map position for this module
	 *
	 * @param int $position
	 * @param string $map
	 *
	 * @return int
	 */
	function lucent_core_woo_set_admin_options_map_position( $position, $map ) {
		
		if ( $map === 'woocommerce' ) {
			$position = 70;
		}
		
		return $position;
	}
	
	add_filter( 'lucent_core_filter_admin_options_map_position', 'lucent_core_woo_set_admin_options_map_position', 10, 2 );
}

if ( ! function_exists( 'lucent_core_include_woocommerce_shortcodes' ) ) {
	/**
	 * Function that includes shortcodes
	 */
	function lucent_core_include_woocommerce_shortcodes() {
		foreach ( glob( LUCENT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/*/include.php' ) as $shortcode ) {
			include_once $shortcode;
		}
	}
	
	add_action( 'qode_framework_action_before_shortcodes_register', 'lucent_core_include_woocommerce_shortcodes' );
}

if ( ! function_exists( 'lucent_core_woo_product_get_rating_html' ) ) {
	/**
	 * Function that return ratings templates
	 *
	 * @param string $html - contains html content
	 * @param float  $rating
	 * @param int    $count - total number of ratings
	 *
	 * @return string
	 */
	function lucent_core_woo_product_get_rating_html( $html, $rating, $count ) {
		return qode_framework_is_installed( 'theme' ) ? lucent_woo_product_get_rating_html( $html, $rating, $count ) : '';
	}
}

if ( ! function_exists( 'lucent_core_woo_get_product_categories' ) ) {
	/**
	 * Function that render product categories
	 *
	 * @param string $before
	 * @param string $after
	 *
	 * @return string
	 */
	function lucent_core_woo_get_product_categories( $before = '', $after = '' ) {
		return qode_framework_is_installed( 'theme' ) ? lucent_woo_get_product_categories( $before, $after ) : '';
	}
}

if(!function_exists('lucent_core_woo_product_category_min_price')){
    /**
     * Function that return category products min price
     * Param $term_slug
     * Return string
     */

    function lucent_core_woo_product_category_min_price($term_id){

        $min_price = 0;
        $product_query_array = array(
            'post_status' => 'publish',
            'post_type' => 'product',
            'ignore_sticky_posts' => 1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field'    => 'id',
                    'terms'    => $term_id,
                ),
            ),
        );

        $products = new WP_Query($product_query_array);
        $counter = 0;

        if($products->have_posts()){
            while ($products->have_posts()){
                $products->the_post();
                $counter++;

                $price = get_post_meta(get_the_ID(), '_price', true);

                if($price && $price !== ''){
                    if($counter === 1){
                        $min_price = $price;
                    }

                    if($price < $min_price){
                        $min_price = $price;
                    }

                }

            }
            wp_reset_postdata();
        }

        return $min_price;
    }
}

if ( ! function_exists( 'lucent_core_woo_add_author' ) ) {
	/**
	 * Function that adds author option to single product
	 */

	function lucent_core_woo_add_author() {
		add_post_type_support( 'product', 'author' );
	}

	add_action('init', 'lucent_core_woo_add_author', 999 );
}
