<?php

if ( ! function_exists( 'lucent_core_add_add_author_info_on_product_page' ) ) {
    /**
     * Function that render sidebar layout for main shop page
     */
    function lucent_core_add_add_author_info_on_product_page() {

        // Include page content sidebar
        lucent_core_template_part( 'plugins/woocommerce', 'templates/single/author-info');
    }
}