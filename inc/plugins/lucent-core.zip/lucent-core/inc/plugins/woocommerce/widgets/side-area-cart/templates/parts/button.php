<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="qodef-button qodef-layout--textual-with-arrow qodef-m-action-link">
        <span class="qodef-m-text"><?php esc_html_e( 'Go to checkout', 'lucent-core' ); ?></span>
    </a>
</div>