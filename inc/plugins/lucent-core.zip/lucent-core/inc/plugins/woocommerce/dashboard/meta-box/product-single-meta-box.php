<?php

if ( ! function_exists( 'lucent_core_add_product_single_product_meta_box' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function lucent_core_add_product_single_product_meta_box() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope' => array( 'product' ),
				'type'  => 'meta',
				'slug'  => 'product-single',
				'title' => esc_html__( 'Product Single', 'lucent-core' )
			)
		);

		if ( $page ) {

            $page->add_field_element(
                array(
                    'field_type'    => 'select',
                    'name'          => 'qodef_woo_single_layout',
                    'title'         => esc_html__( 'Set Single Page Layout', 'lucent-core' ),
                    'description'   => esc_html__( 'Choose Layout on single product page', 'lucent-core' ),
                    'options'       => array(
                        ''              => esc_html__( 'Default', 'lucent-core' ),
                        'standard'      => esc_html__( 'Standard', 'lucent-core' ),
                        'wide-gallery'  => esc_html__( 'Wide Gallery', 'lucent-core' )
                    ),
                    'default_value' => '',
                )
            );

            $page->add_field_element(
                array(
                    'field_type'    => 'select',
                    'name'          => 'qodef_woo_single_enable_author_info',
                    'title'         => esc_html__( 'Enable Author Info', 'lucent-core' ),
                    'options'    => lucent_core_get_select_type_options_pool( 'yes_no' ),
                    'default_value' => '',
                )
            );

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_woo_single_enable_design_info',
					'title'         => esc_html__( 'Disable Design Info', 'lucent-core' ),
					'options'    => lucent_core_get_select_type_options_pool( 'yes_no' ),
					'default_value' => 'no',
				)
			);

			// Hook to include additional options after module options
			do_action( 'lucent_core_action_after_product_single_meta_box_map', $page );
		}
	}

	add_action( 'lucent_core_action_default_meta_boxes_init', 'lucent_core_add_product_single_product_meta_box' );
}