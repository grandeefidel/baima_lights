<?php

include_once LUCENT_CORE_INC_PATH . '/opener-icon/helper.php';