<?php

if ( ! function_exists( 'lucent_core_add_minimal_mobile_header_meta' ) ) {
	/**
	 * Function that add additional mobile header layout meta box options
	 *
	 * @param object $page
	 */
	function lucent_core_add_minimal_mobile_header_meta( $page ) {
		$section = $page->add_section_element(
			array(
				'name'       => 'qodef_minimal_mobile_header_section',
				'title'      => esc_html__( 'Minimal Mobile Header', 'lucent-core' ),
				'dependency' => array(
					'show' => array(
						'qodef_mobile_header_layout' => array(
							'values'        => 'minimal',
							'default_value' => '',
						),
					),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'    => 'select',
				'name'          => 'qodef_minimal_mobile_header_in_grid',
				'title'         => esc_html__( 'Content in Grid', 'lucent-core' ),
				'description'   => esc_html__( 'Set content to be in grid', 'lucent-core' ),
				'default_value' => '',
				'options'       => lucent_core_get_select_type_options_pool( 'no_yes' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_mobile_header_side_padding',
				'title'       => esc_html__( 'Header Side Padding', 'lucent-core' ),
				'description' => esc_html__( 'Set padding that will be applied to minimal mobile header in format: top right bottom left (e.g. 0px 40px 0px 40px)', 'lucent-core' ),
			)
		);

	}

	add_action( 'lucent_core_action_after_page_mobile_header_meta_map', 'lucent_core_add_minimal_mobile_header_meta' );
}
