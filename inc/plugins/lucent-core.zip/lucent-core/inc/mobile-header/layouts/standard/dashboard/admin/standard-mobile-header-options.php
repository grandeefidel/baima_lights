<?php

if ( ! function_exists( 'lucent_core_add_standard_mobile_header_options' ) ) {
	/**
	 * Function that add additional header layout options
	 *
	 * @param object $page
	 * @param array $general_tab
	 */
	function lucent_core_add_standard_mobile_header_options( $page, $general_tab ) {

		$section = $general_tab->add_section_element(
			array(
				'name'       => 'qodef_standard_mobile_header_section',
				'title'      => esc_html__( 'Standard Mobile Header', 'lucent-core' ),
				'dependency' => array(
					'show' => array(
						'qodef_mobile_header_layout' => array(
							'values'        => 'standard',
							'default_value' => '',
						),
					),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'    => 'yesno',
				'name'          => 'qodef_standard_mobile_header_in_grid',
				'title'         => esc_html__( 'Content in Grid', 'lucent-core' ),
				'description'   => esc_html__( 'Set content to be in grid', 'lucent-core' ),
				'default_value' => 'no',
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_standard_mobile_header_height',
				'title'       => esc_html__( 'Header Height', 'lucent-core' ),
				'description' => esc_html__( 'Enter header height', 'lucent-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'lucent-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_standard_mobile_header_side_padding',
				'title'       => esc_html__( 'Header Side Padding', 'lucent-core' ),
				'description' => esc_html__( 'Set padding that will be applied to standard mobile header in format: top right bottom left (e.g. 0px 40px 0px 40px)', 'lucent-core' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_standard_mobile_header_background_color',
				'title'       => esc_html__( 'Header Background Color', 'lucent-core' ),
				'description' => esc_html__( 'Enter header background color', 'lucent-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'lucent-core' ),
				),
			)
		);
	}

	add_action( 'lucent_core_action_after_mobile_header_options_map', 'lucent_core_add_standard_mobile_header_options', 10, 2 );
}
