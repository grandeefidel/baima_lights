<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php
        // Include post date info
        lucent_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/date' );

        lucent_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/title', '', $params ); ?>
	</div>
</article>
