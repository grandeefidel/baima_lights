(function ($) {
	"use strict";
	
	var shortcode = 'lucent_core_blog_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}

	$(document).ready(function () {
		qodefBlogList.init();
	});

	var qodefBlogList = {
		init: function () {
			this.holder = $('.qodef-blog.qodef-item-layout--classic, .qodef-blog.qodef-item-layout--standard, .archive .qodef-blog.qodef--list');

			if ( this.holder.length ) {
				this.holder.each( function () {
					var $thisHolder = $(this);

					qodefBlogList.linkHover( $thisHolder );
				});
			}
		},
		linkHover: function ( $holder ) {
			var $item = $holder.find('.qodef-blog-item');

			$item.each( function() {
				var $thisItem = $(this),
					$itemImage = $thisItem.find('.qodef-e-media'),
					$titleLink = $thisItem.find('.qodef-e-title-link');

				$itemImage.on('mouseenter', function() {
					$itemImage.closest('.qodef-blog-item').addClass('qodef--active');
				});

				$titleLink.on('mouseenter', function() {
					$titleLink.closest('.qodef-blog-item').addClass('qodef--active');
				});

				$itemImage.on('mouseleave', function() {
					$itemImage.closest('.qodef-blog-item').removeClass('qodef--active');
				});

				$titleLink.on('mouseleave', function() {
					$titleLink.closest('.qodef-blog-item').removeClass('qodef--active');
				});
			})
		},
	}
	
})(jQuery);