<?php

include_once LUCENT_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/simple/simple.php';