<?php
$is_enabled = lucent_core_get_post_value_through_levels( 'qodef_blog_single_enable_single_post_navigation' );

if ( $is_enabled === 'yes' ) {
    $through_same_category = lucent_core_get_post_value_through_levels( 'qodef_blog_single_post_navigation_through_same_category' ) === 'yes';
    ?>
    <div id="qodef-single-post-navigation" class="qodef-m">
        <div class="qodef-m-inner">
            <?php
            $post_navigation = array(
                'prev' => array(
                    'label' => '<span class="qodef-m-nav-label"><svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg></span>'
                ),
                'next' => array(
                    'label' => '<span class="qodef-m-nav-label"><svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>'
                )
            );

            if ( $through_same_category ) {
                if ( get_previous_post( true ) !== '' ) {
                    $post_navigation['prev']['post'] = get_previous_post( true );
                    $post_navigation['prev']['title'] = get_the_title( get_previous_post() );
                    $post_navigation['prev']['thumbnail'] = get_the_post_thumbnail($post_navigation['prev']['post'], $size = 'thumbnail');
                }
                if ( get_next_post( true ) !== '' ) {
                    $post_navigation['next']['post'] = get_next_post( true );
                    $post_navigation['next']['title'] = get_the_title( get_next_post() );
                    $post_navigation['next']['thumbnail'] = get_the_post_thumbnail($post_navigation['next']['post'], $size = 'thumbnail');
                }
            } else {
                if ( get_previous_post() !== '' ) {
                    $post_navigation['prev']['post'] = get_previous_post();
                    $post_navigation['prev']['title'] = get_the_title( get_previous_post() );
                    $post_navigation['prev']['thumbnail'] = get_the_post_thumbnail($post_navigation['prev']['post'], $size = 'thumbnail');
                }
                if ( get_next_post() !== '' ) {
                    $post_navigation['next']['post'] = get_next_post();
                    $post_navigation['next']['title'] = get_the_title( get_next_post() );
                    $post_navigation['next']['thumbnail'] = get_the_post_thumbnail($post_navigation['next']['post'], $size = 'thumbnail');
                }
            }

            /* Single navigation section - RENDERING */
            foreach (array('prev', 'next') as $nav_type) {
                if (isset($post_navigation[$nav_type]['post'])) {
                    if ($nav_type == 'prev') {

                        ?>

                        <a itemprop="url" class="qodef-blog-single-<?php echo esc_attr($nav_type); ?>"
                           href="<?php echo get_permalink($post_navigation[$nav_type]['post']->ID); ?>">
                            <?php echo lucent_core_get_formated_output($post_navigation[$nav_type]['thumbnail']); ?>
                            <span class="qodef-m-pagination-title-holder">
                                <span class="qodef-m-pagination-title"><?php echo lucent_core_get_formated_output($post_navigation[$nav_type]['title']); ?></span>
                            <?php echo lucent_core_get_formated_output($post_navigation[$nav_type]['label']); ?>
                            </span>
                        </a>
                    <?php } else if ($nav_type == 'next') {
                        ?>

                        <a itemprop="url" class="qodef-blog-single-<?php echo esc_attr($nav_type); ?>"
                           href="<?php echo get_permalink($post_navigation[$nav_type]['post']->ID); ?>">
                             <span class="qodef-m-pagination-title-holder">
                                <span class="qodef-m-pagination-title"><?php echo lucent_core_get_formated_output($post_navigation[$nav_type]['title']); ?></span>
                            <?php echo lucent_core_get_formated_output($post_navigation[$nav_type]['label']); ?>
                            </span>
                            <?php echo lucent_core_get_formated_output($post_navigation[$nav_type]['thumbnail']); ?>
                        </a>
                    <?php }
                }
            }
            ?>
        </div>
    </div>
<?php } ?>
