<?php if ( $slider_pagination !== 'no' ) { ?>
	<div class="swiper-pagination"></div>
<?php } ?>