(function ($) {
	"use strict";
	
	qodefCore.shortcodes.lucent_core_clients_list = {};
	qodefCore.shortcodes.lucent_core_clients_list.qodefSwiper = qodef.qodefSwiper;
})(jQuery);