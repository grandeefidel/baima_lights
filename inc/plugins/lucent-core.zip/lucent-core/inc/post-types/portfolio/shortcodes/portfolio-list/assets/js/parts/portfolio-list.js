(function ($) {
	"use strict";
	
	var shortcode = 'lucent_core_portfolio_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}

	$(document).ready(function () {
		qodefPortfolioList.init();
	});

	var qodefPortfolioList = {
		init: function () {
			this.holder = $('.qodef-portfolio-list');

			if ( this.holder.length ) {
				this.holder.each( function () {
					var $thisHolder = $(this);

					qodefPortfolioList.linkHover( $thisHolder );
				});
			}
		},
		linkHover: function ( $holder ) {
			var $item = $holder.find('article.portfolio-item');

			$item.each( function() {
				var $thisItem = $(this),
					$itemImage = $thisItem.find('.qodef-e-image'),
					$titleLink = $thisItem.find('.qodef-e-title-link');

				$itemImage.on('mouseenter', function() {
					$itemImage.closest('article.portfolio-item').addClass('qodef--active');
				});

				$titleLink.on('mouseenter', function() {
					$titleLink.closest('article.portfolio-item').addClass('qodef--active');
				});

				$itemImage.on('mouseleave', function() {
					$itemImage.closest('article.portfolio-item').removeClass('qodef--active');
				});

				$titleLink.on('mouseleave', function() {
					$titleLink.closest('article.portfolio-item').removeClass('qodef--active');
				});
			})
		},
	}
	
})(jQuery);