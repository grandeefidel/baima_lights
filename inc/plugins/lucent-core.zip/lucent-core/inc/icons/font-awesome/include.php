<?php

include_once LUCENT_CORE_INC_PATH . '/icons/font-awesome/font-awesome.php';