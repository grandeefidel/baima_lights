(function ($) {
	"use strict";
	
	// This case is important when theme is not active
	if (typeof qodef !== 'object') {
		window.qodef = {};
	}
	
	window.qodefCore = {};
	qodefCore.shortcodes = {};
	qodefCore.listShortcodesScripts = {
		qodefSwiper: qodef.qodefSwiper,
		qodefPagination: qodef.qodefPagination,
		qodefFilter: qodef.qodefFilter,
		qodefMasonryLayout: qodef.qodefMasonryLayout,
		qodefJustifiedGallery: qodef.qodefJustifiedGallery,
	};

	qodefCore.body = $('body');
	qodefCore.html = $('html');
	qodefCore.windowWidth = $(window).width();
	qodefCore.windowHeight = $(window).height();
	qodefCore.scroll = 0;

	$(document).ready(function () {
		qodefCore.scroll = $(window).scrollTop();
		qodefInlinePageStyle.init();
	});

	$(window).resize(function () {
		qodefCore.windowWidth = $(window).width();
		qodefCore.windowHeight = $(window).height();
	});

	$(window).scroll(function () {
		qodefCore.scroll = $(window).scrollTop();
	});

	var qodefScroll = {
		disable: function(){
			if (window.addEventListener) {
				window.addEventListener('wheel', qodefScroll.preventDefaultValue, {passive: false});
			}

			// window.onmousewheel = document.onmousewheel = qodefScroll.preventDefaultValue;
			document.onkeydown = qodefScroll.keyDown;
		},
		enable: function(){
			if (window.removeEventListener) {
				window.removeEventListener('wheel', qodefScroll.preventDefaultValue, {passive: false});
			}
			window.onmousewheel = document.onmousewheel = document.onkeydown = null;
		},
		preventDefaultValue: function(e){
			e = e || window.event;
			if (e.preventDefault) {
				e.preventDefault();
			}
			e.returnValue = false;
		},
		keyDown: function(e) {
			var keys = [37, 38, 39, 40];
			for (var i = keys.length; i--;) {
				if (e.keyCode === keys[i]) {
					qodefScroll.preventDefaultValue(e);
					return;
				}
			}
		}
	};

	qodefCore.qodefScroll = qodefScroll;

	var qodefPerfectScrollbar = {
		init: function ( $holder ) {
			if ( $holder.length ) {
				qodefPerfectScrollbar.qodefInitScroll( $holder );
			}
		},
		qodefInitScroll: function ( $holder ) {
			var $defaultParams = {
				wheelSpeed: 0.6,
				suppressScrollX: true
			};

			var $ps = new PerfectScrollbar(
				$holder[0],
				$defaultParams
			);

			$( window ).resize(
				function () {
					$ps.update();
				}
			);
		}
	};

	qodefCore.qodefPerfectScrollbar = qodefPerfectScrollbar;

	var qodefInlinePageStyle = {
		init: function () {
			this.holder = $('#lucent-core-page-inline-style');

			if (this.holder.length) {
				var style = this.holder.data('style');

				if (style.length) {
					$('head').append('<style type="text/css">' + style + '</style>');
				}
			}
		}
	};

})(jQuery);

(function ( $ ) {
    'use strict';

    $( document ).ready(
        function () {
            qodefBackToTop.init();
        }
    );

    var qodefBackToTop = {
        init: function () {
            this.holder = $( '#qodef-back-to-top' );

            if ( this.holder.length ) {
                // Scroll To Top
                this.holder.on(
                    'click',
                    function ( e ) {
                        e.preventDefault();
                        qodefBackToTop.animateScrollToTop();
                    }
                );

                qodefBackToTop.showHideBackToTop();
            }
        },
        animateScrollToTop: function () {
            var startPos = qodef.scroll,
                newPos   = qodef.scroll,
                step     = .9,
                animationFrameId;

            var startAnimation = function () {
                if ( newPos === 0 ) {
                    return;
                }

                newPos < 0.0001 ? newPos = 0 : null;

                var ease = qodefBackToTop.easingFunction( (startPos - newPos) / startPos );
                $( 'html, body' ).scrollTop( startPos - (startPos - newPos) * ease );
                newPos = newPos * step;

                animationFrameId = requestAnimationFrame( startAnimation );
            };
            startAnimation();
            $( window ).one(
                'wheel touchstart',
                function () {
                    cancelAnimationFrame( animationFrameId );
                }
            );
        },
        easingFunction: function ( n ) {
            return 0 == n ? 0 : Math.pow( 1024, n - 1 );
        },
        showHideBackToTop: function () {
            $( window ).scroll( function () {
                var $thisItem = $( this ),
                    b         = $thisItem.scrollTop(),
                    c         = $thisItem.height(),
                    d;

                if ( b > 0 ) {
                    d = b + c / 2;
                } else {
                    d = 1;
                }

                if ( d < 1e3 ) {
                    qodefBackToTop.addClass( 'off' );
                } else {
                    qodefBackToTop.addClass( 'on' );
                }
            } );
        },
        addClass: function ( a ) {
            this.holder.removeClass( 'qodef--off qodef--on' );

            if ( a === 'on' ) {
                this.holder.addClass( 'qodef--on' );
            } else {
                this.holder.addClass( 'qodef--off' );
            }
        }
    };

})( jQuery );

(function ($) {
	"use strict";

	$( window ).on(
		'load',
		function () {
		qodefUncoverFooter.init();
	});
	
	var qodefUncoverFooter = {
		holder: '',
		init: function () {
			this.holder = $('#qodef-page-footer.qodef--uncover');
			
			if (this.holder.length && !qodefCore.html.hasClass('touchevents')) {
				qodefUncoverFooter.addClass();
				qodefUncoverFooter.setHeight(this.holder);
				
				$(window).resize(function () {
                    qodefUncoverFooter.setHeight(qodefUncoverFooter.holder);
				});
			}
		},
        setHeight: function ($holder) {
	        $holder.css('height', 'auto');
	        
            var footerHeight = $holder.outerHeight();
            
            if (footerHeight > 0) {
                $('#qodef-page-outer').css({'margin-bottom': footerHeight, 'background-color': qodefCore.body.css('backgroundColor')});
                $holder.css('height', footerHeight);
            }
        },
		addClass: function () {
			qodefCore.body.addClass('qodef-page-footer--uncover');
		}
	};
	
})(jQuery);

(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefFullscreenMenu.init();
	});
	
	var qodefFullscreenMenu = {
		init: function () {
			var $fullscreenMenuOpener = $('a.qodef-fullscreen-menu-opener'),
				$menuItems = $('#qodef-fullscreen-area nav ul li a');
			
			// Open popup menu
			$fullscreenMenuOpener.on('click', function (e) {
				e.preventDefault();
				var $thisOpener = $(this);
				
				if (!qodefCore.body.hasClass('qodef-fullscreen-menu--opened')) {
					qodefFullscreenMenu.openFullscreen($thisOpener);
					
					$(document).keyup(function (e) {
						if (e.keyCode === 27) {
							qodefFullscreenMenu.closeFullscreen($thisOpener);
						}
					});
				} else {
					qodefFullscreenMenu.closeFullscreen($thisOpener);
				}
			});
			
			//open dropdowns
			$menuItems.on('tap click', function (e) {
				var $thisItem = $(this);
				
				if ($thisItem.parent().hasClass('menu-item-has-children')) {
					e.preventDefault();
					qodefFullscreenMenu.clickItemWithChild($thisItem);
				} else if ($thisItem.attr('href') !== "http://#" && $thisItem.attr('href') !== "#") {
					qodefFullscreenMenu.closeFullscreen($fullscreenMenuOpener);
				}
			});
		},
		openFullscreen: function ($opener) {
			$opener.addClass('qodef--opened');
			qodefCore.body.removeClass('qodef-fullscreen-menu-animate--out').addClass('qodef-fullscreen-menu--opened qodef-fullscreen-menu-animate--in');
			qodefCore.qodefScroll.disable();
		},
		closeFullscreen: function ($opener) {
			$opener.removeClass('qodef--opened');
			qodefCore.body.removeClass('qodef-fullscreen-menu--opened qodef-fullscreen-menu-animate--in').addClass('qodef-fullscreen-menu-animate--out');
			qodefCore.qodefScroll.enable();
			$("nav.qodef-fullscreen-menu ul.sub_menu").slideUp(200);
		},
		clickItemWithChild: function (thisItem) {
			var $thisItemParent = thisItem.parent(),
				$thisItemSubMenu = $thisItemParent.find('.sub-menu').first();
			
			if ($thisItemSubMenu.is(':visible')) {
				$thisItemSubMenu.slideUp(300);
				$thisItemParent.removeClass('qodef--opened');
			} else {
				$thisItemSubMenu.slideDown(300);
				$thisItemParent.addClass('qodef--opened').siblings().find('.sub-menu').slideUp(400);
			}
		}
	};
	
})(jQuery);
(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefHeaderScrollAppearance.init();
	});
	
	var qodefHeaderScrollAppearance = {
		appearanceType: function () {
			return qodefCore.body.attr('class').indexOf('qodef-header-appearance--') !== -1 ? qodefCore.body.attr('class').match(/qodef-header-appearance--([\w]+)/)[1] : '';
		},
		init: function () {
			var appearanceType = this.appearanceType();
			
			if (appearanceType !== '' && appearanceType !== 'none') {
                qodefCore[appearanceType + "HeaderAppearance"]();
			}
		}
	};
	
})(jQuery);

(function ($) {
    "use strict";

    $(document).ready(function () {
        qodefMobileHeaderAppearance.init();
    });

    /*
     **	Init mobile header functionality
     */
    var qodefMobileHeaderAppearance = {
        init: function () {
            if (qodefCore.body.hasClass('qodef-mobile-header-appearance--sticky')) {

                var docYScroll1 = qodefCore.scroll,
                    displayAmount = qodefGlobal.vars.mobileHeaderHeight + qodefGlobal.vars.adminBarHeight,
                    $pageOuter = $('#qodef-page-outer');

                qodefMobileHeaderAppearance.showHideMobileHeader(docYScroll1, displayAmount, $pageOuter);
                $(window).scroll(function () {
                    qodefMobileHeaderAppearance.showHideMobileHeader(docYScroll1, displayAmount, $pageOuter);
                    docYScroll1 = qodefCore.scroll;
                });

                $(window).resize(function () {
                    $pageOuter.css('padding-top', 0);
                    qodefMobileHeaderAppearance.showHideMobileHeader(docYScroll1, displayAmount, $pageOuter);
                });
            }
        },
        showHideMobileHeader: function(docYScroll1, displayAmount,$pageOuter){
            if(qodefCore.windowWidth <= 1024) {
                if (qodefCore.scroll > displayAmount * 2) {
                    //set header to be fixed
                    qodefCore.body.addClass('qodef-mobile-header--sticky');

                    //add transition to it
                    setTimeout(function () {
                        qodefCore.body.addClass('qodef-mobile-header--sticky-animation');
                    }, 300); //300 is duration of sticky header animation

                    //add padding to content so there is no 'jumping'
                    $pageOuter.css('padding-top', qodefGlobal.vars.mobileHeaderHeight);
                } else {
                    //unset fixed header
                    qodefCore.body.removeClass('qodef-mobile-header--sticky');

                    //remove transition
                    setTimeout(function () {
                        qodefCore.body.removeClass('qodef-mobile-header--sticky-animation');
                    }, 300); //300 is duration of sticky header animation

                    //remove padding from content since header is not fixed anymore
                    $pageOuter.css('padding-top', 0);
                }

                if ((qodefCore.scroll > docYScroll1 && qodefCore.scroll > displayAmount) || (qodefCore.scroll < displayAmount * 3)) {
                    //show sticky header
                    qodefCore.body.removeClass('qodef-mobile-header--sticky-display');
                } else {
                    //hide sticky header
                    qodefCore.body.addClass('qodef-mobile-header--sticky-display');
                }
            }
        }
    };

})(jQuery);
(function ($) {
	"use strict";

	$(document).ready(function () {
		qodefNavMenu.init();
	});

	var qodefNavMenu = {
		init: function () {
			qodefNavMenu.dropdownBehavior();
			qodefNavMenu.wideDropdownPosition();
			qodefNavMenu.dropdownPosition();
		},
		dropdownBehavior: function () {
			var $menuItems = $('.qodef-header-navigation > ul > li');
			
			$menuItems.each(function () {
				var $thisItem = $(this);
				
				if ($thisItem.find('.qodef-drop-down-second').length) {
					$thisItem.waitForImages(function () {
						var $dropdownHolder = $thisItem.find('.qodef-drop-down-second'),
							$dropdownMenuItem = $dropdownHolder.find('.qodef-drop-down-second-inner ul'),
							dropDownHolderHeight = $dropdownMenuItem.outerHeight();
						
						if (navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
							$thisItem.on("touchstart mouseenter", function () {
								$dropdownHolder.css({
									'height': dropDownHolderHeight,
									'overflow': 'visible',
									'visibility': 'visible',
									'opacity': '1'
								});
							}).on("mouseleave", function () {
								$dropdownHolder.css({
									'height': '0px',
									'overflow': 'hidden',
									'visibility': 'hidden',
									'opacity': '0'
								});
							});
						} else {
							if (qodefCore.body.hasClass('qodef-drop-down-second--animate-height')) {
								var animateConfig = {
									interval: 0,
									over: function () {
										setTimeout(function () {
											$dropdownHolder.addClass('qodef-drop-down--start').css({
												'visibility': 'visible',
												'height': '0',
												'opacity': '1'
											});
											$dropdownHolder.stop().animate({
												'height': dropDownHolderHeight
											}, 400, 'easeInOutQuint', function () {
												$dropdownHolder.css('overflow', 'visible');
											});
										}, 100);
									},
									timeout: 100,
									out: function () {
										$dropdownHolder.stop().animate({
											'height': '0',
											'opacity': 0
										}, 100, function () {
											$dropdownHolder.css({
												'overflow': 'hidden',
												'visibility': 'hidden'
											});
										});
										
										$dropdownHolder.removeClass('qodef-drop-down--start');
									}
								};
								
								$thisItem.hoverIntent(animateConfig);
							} else {
								var config = {
									interval: 0,
									over: function () {
										setTimeout(function () {
											$dropdownHolder.addClass('qodef-drop-down--start').stop().css({'height': dropDownHolderHeight});
										}, 150);
									},
									timeout: 150,
									out: function () {
										$dropdownHolder.stop().css({'height': '0'}).removeClass('qodef-drop-down--start');
									}
								};
								
								$thisItem.hoverIntent(config);
							}
						}
					});
				}
			});
		},
		wideDropdownPosition: function () {
			var $menuItems = $(".qodef-header-navigation > ul > li.qodef-menu-item--wide");

			if ($menuItems.length) {
				$menuItems.each(function () {
					var $menuItem = $(this);
					var $menuItemSubMenu = $menuItem.find('.qodef-drop-down-second');

					if ($menuItemSubMenu.length) {
						$menuItemSubMenu.css('left', 0);

						var leftPosition = $menuItemSubMenu.offset().left;

						if (qodefCore.body.hasClass('qodef--boxed')) {
							//boxed layout case
							var boxedWidth = $('.qodef--boxed #qodef-page-wrapper').outerWidth();
							leftPosition = leftPosition - (qodefCore.windowWidth - boxedWidth) / 2;
							$menuItemSubMenu.css({'left': -leftPosition, 'width': boxedWidth});

						} else if (qodefCore.body.hasClass('qodef-drop-down-second--full-width')) {
							//wide dropdown full width case
							$menuItemSubMenu.css({'left': -leftPosition});
						}
						else {
							//wide dropdown in grid case
							$menuItemSubMenu.css({'left': -leftPosition + (qodefCore.windowWidth - $menuItemSubMenu.width()) / 2});
						}
					}
				});
			}
		},
		dropdownPosition: function () {
			var $menuItems = $('.qodef-header-navigation > ul > li.qodef-menu-item--narrow.menu-item-has-children');

			if ($menuItems.length) {
				$menuItems.each(function () {
					var $thisItem = $(this),
						menuItemPosition = $thisItem.offset().left,
						$dropdownHolder = $thisItem.find('.qodef-drop-down-second'),
						$dropdownMenuItem = $dropdownHolder.find('.qodef-drop-down-second-inner ul'),
						dropdownMenuWidth = $dropdownMenuItem.outerWidth(),
						menuItemFromLeft = $(window).width() - menuItemPosition;

                    if (qodef.body.hasClass('qodef--boxed')) {
                        //boxed layout case
                        var boxedWidth = $('.qodef--boxed #qodef-page-wrapper').outerWidth();
                        menuItemFromLeft = boxedWidth - menuItemPosition;
                    }

					var dropDownMenuFromLeft;

					if ($thisItem.find('li.menu-item-has-children').length > 0) {
						dropDownMenuFromLeft = menuItemFromLeft - dropdownMenuWidth;
					}

					$dropdownHolder.removeClass('qodef-drop-down--right');
					$dropdownMenuItem.removeClass('qodef-drop-down--right');
					if (menuItemFromLeft < dropdownMenuWidth || dropDownMenuFromLeft < dropdownMenuWidth) {
						$dropdownHolder.addClass('qodef-drop-down--right');
						$dropdownMenuItem.addClass('qodef-drop-down--right');
					}
				});
			}
		}
	};

})(jQuery);
(function ($) {
    "use strict";

    $( window ).on(
        'load',
        function () {
        qodefParallaxBackground.init();
    });

    /**
     * Init global parallax background functionality
     */
    var qodefParallaxBackground = {
        init: function (settings) {
            this.$sections = $('.qodef-parallax');

            // Allow overriding the default config
            $.extend(this.$sections, settings);

            var isSupported = !qodefCore.html.hasClass('touchevents') && !qodefCore.body.hasClass('qodef-browser--edge') && !qodefCore.body.hasClass('qodef-browser--ms-explorer');

            if (this.$sections.length && isSupported) {
                this.$sections.each(function () {
                    qodefParallaxBackground.ready($(this));
                });
            }
        },
        ready: function ($section) {
            $section.$imgHolder = $section.find('.qodef-parallax-img-holder');
            $section.$imgWrapper = $section.find('.qodef-parallax-img-wrapper');
            $section.$img = $section.find('img.qodef-parallax-img');

            var h = $section.height(),
                imgWrapperH = $section.$imgWrapper.height();

            $section.movement = 100 * (imgWrapperH - h) / h / 2; //percentage (divided by 2 due to absolute img centering in CSS)

            $section.buffer = window.pageYOffset;
            $section.scrollBuffer = null;

			
            //calc and init loop
            requestAnimationFrame(function () {
				$section.$imgHolder.animate({opacity: 1}, 100);
                qodefParallaxBackground.calc($section);
                qodefParallaxBackground.loop($section);
            });

            //recalc
            $(window).on('resize', function () {
                qodefParallaxBackground.calc($section);
            });
        },
        calc: function ($section) {
            var wH = $section.$imgWrapper.height(),
                wW = $section.$imgWrapper.width();

            if ($section.$img.width() < wW) {
                $section.$img.css({
                    'width': '100%',
                    'height': 'auto'
                });
            }

            if ($section.$img.height() < wH) {
                $section.$img.css({
                    'height': '100%',
                    'width': 'auto',
                    'max-width': 'unset'
                });
            }
        },
        loop: function ($section) {
            if ($section.scrollBuffer === Math.round(window.pageYOffset)) {
                requestAnimationFrame(function () {
                    qodefParallaxBackground.loop($section);
                }); //repeat loop
                return false; //same scroll value, do nothing
            } else {
                $section.scrollBuffer = Math.round(window.pageYOffset);
            }

            var wH = window.outerHeight,
                sTop = $section.offset().top,
                sH = $section.height();

            if ($section.scrollBuffer + wH * 1.2 > sTop && $section.scrollBuffer < sTop + sH) {
                var delta = (Math.abs($section.scrollBuffer + wH - sTop) / (wH + sH)).toFixed(4), //coeff between 0 and 1 based on scroll amount
                    yVal = (delta * $section.movement).toFixed(4);

                if ($section.buffer !== delta) {
                    $section.$imgWrapper.css('transform', 'translate3d(0,' + yVal + '%, 0)');
                }

                $section.buffer = delta;
            }

            requestAnimationFrame(function () {
                qodefParallaxBackground.loop($section);
            }); //repeat loop
        }
    };

    qodefCore.qodefParallaxBackground = qodefParallaxBackground;

})(jQuery);

(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefReview.init();
	});
	
	var qodefReview = {
		init: function () {
			var ratingHolder = $('#qodef-page-comments-form .qodef-rating-inner');
			
			var addActive = function (stars, ratingValue) {
				for (var i = 0; i < stars.length; i++) {
					var star = stars[i];
					if (i < ratingValue) {
						$(star).addClass('active');
					} else {
						$(star).removeClass('active');
					}
				}
			};
			
			ratingHolder.each(function () {
				var thisHolder = $(this),
					ratingInput = thisHolder.find('.qodef-rating'),
					ratingValue = ratingInput.val(),
					stars = thisHolder.find('.qodef-star-rating');
				
				addActive(stars, ratingValue);
				
				stars.on('click', function () {
					ratingInput.val($(this).data('value')).trigger('change');
				});
				
				ratingInput.change(function () {
					ratingValue = ratingInput.val();
					addActive(stars, ratingValue);
				});
			});
		}
	}
})(jQuery);
(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefSideArea.init();
	});
	
	var qodefSideArea = {
		init: function () {
			var $sideAreaOpener = $('a.qodef-side-area-opener'),
				$sideAreaClose = $('#qodef-side-area-close'),
				$sideArea = $('#qodef-side-area');
				qodefSideArea.openerHoverColor($sideAreaOpener);
			// Open Side Area
			$sideAreaOpener.on('click', function (e) {
				e.preventDefault();
				
				if (!qodefCore.body.hasClass('qodef-side-area--opened')) {
					qodefSideArea.openSideArea();
					
					$(document).keyup(function (e) {
						if (e.keyCode === 27) {
							qodefSideArea.closeSideArea();
						}
					});
				} else {
					qodefSideArea.closeSideArea();
				}
			});
			
			$sideAreaClose.on('click', function (e) {
				e.preventDefault();
				qodefSideArea.closeSideArea();
			});
			
			if ($sideArea.length && typeof qodefCore.qodefPerfectScrollbar === 'object') {
				qodefCore.qodefPerfectScrollbar.init($sideArea);
			}
		},
		openSideArea: function () {
			var $wrapper = $('#qodef-page-wrapper');
			var currentScroll = $(window).scrollTop();

			$('.qodef-side-area-cover').remove();
			$wrapper.prepend('<div class="qodef-side-area-cover"/>');
			qodefCore.body.removeClass('qodef-side-area-animate--out').addClass('qodef-side-area--opened qodef-side-area-animate--in');

			$('.qodef-side-area-cover').on('click', function (e) {
				e.preventDefault();
				qodefSideArea.closeSideArea();
			});

			$(window).scroll(function () {
				if (Math.abs(qodefCore.scroll - currentScroll) > 400) {
					qodefSideArea.closeSideArea();
				}
			});

		},
		closeSideArea: function () {
			qodefCore.body.removeClass('qodef-side-area--opened qodef-side-area-animate--in').addClass('qodef-side-area-animate--out');
		},
		openerHoverColor: function ($opener) {
			if (typeof $opener.data('hover-color') !== 'undefined') {
				var hoverColor = $opener.data('hover-color');
				var originalColor = $opener.css('color');
				
				$opener.on('mouseenter', function () {
					$opener.css('color', hoverColor);
				}).on('mouseleave', function () {
					$opener.css('color', originalColor);
				});
			}
		}
	};
	
})(jQuery);

(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefSpinner.init();
	});

	$(window).on('elementor/frontend/init', function() {
		var isEditMode = Boolean(elementorFrontend.isEditMode());
        if (isEditMode) {
			qodefSpinner.init(isEditMode);
		}
    });
	
	var qodefSpinner = {
		init: function (isEditMode) {
			this.holder = $('#qodef-page-spinner:not(.qodef-layout--lucent)');
			
			if (this.holder.length) {
				qodefSpinner.animateSpinner(this.holder, isEditMode);
				qodefSpinner.fadeOutAnimation();
			}
		},
		animateSpinner: function ($holder, isEditMode) {
			$(window).on('load', function () {
				qodefSpinner.fadeOutLoader($holder);
			});

			if (isEditMode) {
				qodefSpinner.fadeOutLoader($holder);
			}
		},
		fadeOutLoader: function ($holder, speed, delay, easing) {
			speed = speed ? speed : 600;
			delay = delay ? delay : 0;
			easing = easing ? easing : 'swing';
			
			$holder.delay(delay).fadeOut(speed, easing);
			
			$(window).on('bind', 'pageshow', function (event) {
				if (event.originalEvent.persisted) {
					$holder.fadeOut(speed, easing);
				}
			});
		},
		fadeOutAnimation: function () {
			
			// Check for fade out animation
			if (qodefCore.body.hasClass('qodef-spinner--fade-out')) {
				var $pageHolder = $('#qodef-page-wrapper'),
					$linkItems = $('a');
				
				// If back button is pressed, than show content to avoid state where content is on display:none
				window.addEventListener("pageshow", function (event) {
					var historyPath = event.persisted || (typeof window.performance !== "undefined" && window.performance.navigation.type === 2);
					if (historyPath && !$pageHolder.is(':visible')) {
						$pageHolder.show();
					}
				});
				
				$linkItems.on('click', function (e) {
					var $clickedLink = $(this);

					if (
						e.which === 1 && // check if the left mouse button has been pressed
						$clickedLink.attr('href').indexOf(window.location.host) >= 0 && // check if the link is to the same domain
						!$clickedLink.hasClass('remove') && // check is WooCommerce remove link
						$clickedLink.parent('.product-remove').length <= 0 && // check is WooCommerce remove link
						$clickedLink.parents('.woocommerce-product-gallery__image').length <= 0 && // check is product gallery link
						typeof $clickedLink.data('rel') === 'undefined' && // check pretty photo link
						typeof $clickedLink.attr('rel') === 'undefined' && // check VC pretty photo link
						!$clickedLink.hasClass('lightbox-active') && // check is lightbox plugin active
						(typeof $clickedLink.attr('target') === 'undefined' || $clickedLink.attr('target') === '_self') && // check if the link opens in the same window
						$clickedLink.attr('href').split('#')[0] !== window.location.href.split('#')[0] // check if it is an anchor aiming for a different page
					) {
						e.preventDefault();
				
						$pageHolder.fadeOut(600, 'easeOutSine', function () {
							window.location = $clickedLink.attr('href');
						});
					}
				});
			}
		}
	}
	
})(jQuery);
(function ($) {
    "use strict";

    $( window ).on(
        'load',
        function () {
        qodefSubscribeModal.init();
    });

    var qodefSubscribeModal = {
        init: function () {
            this.holder = $('#qodef-subscribe-popup-modal');

            if (this.holder.length) {
                var $preventHolder = this.holder.find('.qodef-sp-prevent'),
                    $modalClose = $('.qodef-sp-close'),
                    disabledPopup = 'no';

                if ($preventHolder.length) {
                    var isLocalStorage = this.holder.hasClass('qodef-sp-prevent-cookies'),
                        $preventInput = $preventHolder.find('.qodef-sp-prevent-input'),
                        preventValue = $preventInput.data('value');

                    if (isLocalStorage) {
                        disabledPopup = localStorage.getItem('disabledPopup');
                        sessionStorage.removeItem('disabledPopup');
                    } else {
                        disabledPopup = sessionStorage.getItem('disabledPopup');
                        localStorage.removeItem('disabledPopup');
                    }

                    $preventHolder.children().on('click', function (e) {
                        if (preventValue !== 'yes') {
                            preventValue = 'yes';
                            $preventInput.addClass('qodef-sp-prevent-clicked').data('value', 'yes');
                        } else {
                            preventValue = 'no';
                            $preventInput.removeClass('qodef-sp-prevent-clicked').data('value', 'no');
                        }

                        if (preventValue === 'yes') {
                            if (isLocalStorage) {
                                localStorage.setItem('disabledPopup', 'yes');
                            } else {
                                sessionStorage.setItem('disabledPopup', 'yes');
                            }
                        } else {
                            if (isLocalStorage) {
                                localStorage.setItem('disabledPopup', 'no');
                            } else {
                                sessionStorage.setItem('disabledPopup', 'no');
                            }
                        }
                    });
                }

                if (disabledPopup !== 'yes') {
                    var showOnLoad = false; /* change behavior here */

                    if ( showOnLoad ) {
                        if (qodefCore.body.hasClass('qodef-sp-opened')) {
                            qodefSubscribeModal.handleClassAndScroll('remove');
                        } else {
                            qodefSubscribeModal.handleClassAndScroll('add');
                        }
                    } else {
                        /* show on scroll */
                        $(window).on('scroll', function(){
                            qodefSubscribeModal.handleScroll(disabledPopup);
                        });
                    }

                    $modalClose.on('click', function (e) {
                        e.preventDefault();
                        disabledPopup = 'yes';
                        qodefSubscribeModal.handleClassAndScroll('remove');
                    });

                    // Close on escape
                    $(document).keyup(function (e) {
                        if (e.keyCode === 27) { // KeyCode for ESC button is 27
                            disabledPopup = 'yes';
                            qodefSubscribeModal.handleClassAndScroll('remove');
                        }
                    });
                }
            }
        },

        handleClassAndScroll: function (option, preventScroll) {
            preventScroll = preventScroll || false;

            if (option === 'remove') {
                qodefCore.body.removeClass('qodef-sp-opened');
                if ( ! preventScroll ) {
                    qodefCore.qodefScroll.enable();
                }
            }
            if (option === 'add') {
                qodefCore.body.addClass('qodef-sp-opened');
                if ( ! preventScroll ) {
                    qodefCore.qodefScroll.disable();
                }
            }
        },

        handleScroll: function(disabledPopup) {
            var slider = $('.qodef-slider'),
                start = slider.length ? slider.height() : 0,
                end = $('#qodef-page-outer').outerHeight();

            if (window.scrollY >= start && window.scrollY + window.innerHeight <= end && disabledPopup !== 'yes') {
                qodefSubscribeModal.handleClassAndScroll('add', true);
            } else {
                qodefSubscribeModal.handleClassAndScroll('remove', true);
            }
        }
    };

})(jQuery);

// (function ($) {
//     "use strict";
//
//     $( window ).on(
// 		'load',
// 		function () {
//         qodefStickyColumn.init('init');
//     });
//
//     $(window).resize(function () {
//         qodefStickyColumn.init('resize');
//     });
//
//     var qodefStickyColumn = {
//         pageOffset: '',
//         scrollAmount: '',
//
//         init: function (state) {
//             var $holder = $('.qodef-sticky-column'),
//                 editor = $holder.hasClass('wpb_column') ? 'wp_bakery' : 'elementor';
//
//             if ($holder.length) {
//                 $holder.each(function () {
//                     qodefStickyColumn.calculateVars($(this), state, editor);
//                 });
//             }
//         },
//         calculateVars: function ($column, state, editor) {
//             var columnVars = {};
//
//             if ('wp_bakery' === editor) {
//                 columnVars.$columnInner = $column.find('.vc_column-inner');
//             } else {
//                 columnVars.$columnInner = $column.find('.elementor-column-wrap');
//             }
//
//             columnVars.columnTopEdgePosition = $column.offset().top;
//             columnVars.columnLeftEdgePosition = $column.offset().left;
//             columnVars.columnWidth = $column.outerWidth(true);
//             columnVars.columnHeight = columnVars.$columnInner.outerHeight(true);
//
//             if ('wp_bakery' === editor) {
//                 columnVars.$row = $column.closest('.vc_row');
//             } else {
//                 columnVars.$row = $column.closest('.elementor-section');
//             }
//
//             columnVars.rowTopEdgePosition = columnVars.$row.offset().top;
//             columnVars.rowHeight = columnVars.$row.outerHeight(true);
//             columnVars.rowBottomEdgePosition = columnVars.rowTopEdgePosition + columnVars.rowHeight;
//             qodefStickyColumn.scrollAmount = qodef.scroll;
//
//             qodefStickyColumn.checkPosition(columnVars);
//
//             $(window).scroll(function () {
//                 if ('init' === state) {
//                     var scrollDirection = qodefStickyColumn.checkScrollDirection();
//                 }
//
//                 qodefStickyColumn.checkPosition(columnVars, scrollDirection);
//             });
//         },
//         checkPosition: function (columnVars, direction) {
//
//             if (qodef.windowWidth > 1024) {
//                 qodefStickyColumn.calculateOffset();
//
//                 if ((qodef.scroll + qodefStickyColumn.pageOffset) <= columnVars.columnTopEdgePosition) {
//                     qodefStickyColumn.setPosition(columnVars, 'relative');
//                 }
//
//                 if (((qodef.scroll + qodefStickyColumn.pageOffset) >= columnVars.columnTopEdgePosition) && ((qodef.scroll + qodefStickyColumn.pageOffset + columnVars.columnHeight) < columnVars.rowBottomEdgePosition)) {
//                     qodefStickyColumn.setPosition(columnVars, 'fixed', direction);
//                 } else if ((qodef.scroll + qodefStickyColumn.pageOffset + columnVars.columnHeight) >= columnVars.rowBottomEdgePosition) {
//                     qodefStickyColumn.setPosition(columnVars, 'absolute');
//                 }
//             } else {
//                 qodefStickyColumn.setPosition(columnVars, 'relative');
//             }
//         },
//         calculateOffset: function () {
//             qodefStickyColumn.pageOffset = 0;
//
//             if ($('body').hasClass('admin-bar')) {
//                 qodefStickyColumn.pageOffset += 32;
//             }
//
//             if ($('body').hasClass('qodef-header--sticky-display') && $('.qodef-header-sticky').length) {
//                 qodefStickyColumn.pageOffset += parseInt($('.qodef-header-sticky').outerHeight(true));
//             }
//
//             if ($('body').hasClass('qodef-header--fixed-display')) {
//                 qodefStickyColumn.pageOffset += parseInt($('#qodef-page-header').outerHeight(true));
//                 qodefStickyColumn.pageOffset += parseInt($('#qodef-page-header').css('margin-top'));
//             }
//         },
//         checkScrollDirection: function () {
//             var scrollDirection = (qodef.scroll > qodefStickyColumn.scrollAmount) ? 'down' : 'up';
//
//             qodefStickyColumn.scrollAmount = qodef.scroll;
//
//             return scrollDirection;
//         },
//         setPosition: function (columnVars, position, direction) {
//             if ('relative' === position) {
//                 columnVars.$columnInner.css({
//                     'bottom': 'auto',
//                     'left': 'auto',
//                     'position': 'relative',
//                     'top': 'auto',
//                     'width': columnVars.columnWidth,
//                     'transform': 'translateY(0)',
//                     'transition': 'none'
//                 });
//             }
//             if ('fixed' === position) {
//                 if ($('body').hasClass('qodef-header--fixed-display')) {
//                     var transitionValue = ('up' === direction) ? 'none' : 'transform .5s ease';
//                 }
//
//                 columnVars.$columnInner.css({
//                     'bottom': 'auto',
//                     'left': columnVars.columnLeftEdgePosition,
//                     'position': 'fixed',
//                     'top': 0,
//                     'width': columnVars.columnWidth,
//                     'transform': 'translateY(' + qodefStickyColumn.pageOffset + 'px)',
//                     'transition': transitionValue
//                 });
//             }
//             if ('absolute' === position) {
//                 columnVars.$columnInner.css({
//                     'bottom': -columnVars.rowHeight,
//                     'left': '0',
//                     'position': 'absolute',
//                     'top': 'auto',
//                     'width': columnVars.columnWidth,
//                     'transform': 'translateY(0)',
//                     'transition': 'none'
//                 });
//             }
//         }
//     };
//
//     window.qodefStickyColumn = qodefStickyColumn;
// })(jQuery);

(function ($) {
    "use strict";

    $(document).ready(function () {
	    $(".qodef-portfolio .qodef-media a").removeAttr("title");
	    $(".qodef-portfolio .swiper-slide").removeAttr("title");
	    qodefPortfolioSingleFollow().init();
    });
    
	var qodefPortfolioSingleFollow = function () {

		var info = $(' .qodef-portfolio-single .qodef-ps-info-sticky-holder');
		
		if (info.length) {
			var infoHolder = info.parent(),
				infoHolderOffset = infoHolder.offset().top,
				infoHolderHeight = infoHolder.height(),
				mediaHolder = $('.qodef-ps-image-holder'),
				mediaHolderHeight = mediaHolder.height(),
				header = $('.header-appear, .qodef-fixed-wrapper'),
				headerHeight = (header.length) ? header.height() : 0,
				constant = 30; //30 to prevent mispositioned
		}
		
		var infoHolderPosition = function () {
			if (info.length && mediaHolderHeight >= infoHolderHeight) {
				if (qodef.scroll >= infoHolderOffset - headerHeight - qodefGlobal.vars.adminBarHeight - constant) {
					var marginTop = qodef.scroll - infoHolderOffset + qodefGlobal.vars.adminBarHeight + headerHeight + constant;
					// if scroll is initially positioned below mediaHolderHeight
					if (marginTop + infoHolderHeight > mediaHolderHeight) {
						marginTop = mediaHolderHeight - infoHolderHeight + constant;
					}
					info.stop().animate({
						marginTop: marginTop
					});
				}
			}
		};
		
		var recalculateInfoHolderPosition = function () {
			if (info.length && mediaHolderHeight >= infoHolderHeight) {
				//Calculate header height if header appears
				if (qodef.scroll > 0 && header.length) {
					headerHeight = header.height();
				}
				
				var headerMixin = headerHeight + qodefGlobal.vars.adminBarHeight + constant;
				if (qodef.scroll >= infoHolderOffset - headerMixin) {
					if (qodef.scroll + infoHolderHeight + headerMixin + 2 * constant < infoHolderOffset + mediaHolderHeight) {
						info.stop().animate({
							marginTop: (qodef.scroll - infoHolderOffset + headerMixin + 2 * constant)
						});
						//Reset header height
						headerHeight = 0;
					} else {
						info.stop().animate({
							marginTop: mediaHolderHeight - infoHolderHeight
						});
					}
				} else {
					info.stop().animate({
						marginTop: 0
					});
				}
				
			}
		};
		
		return {
			init: function () {
				infoHolderPosition();
				$(window).scroll(function () {
					recalculateInfoHolderPosition();
				});
			}
		};
	};
    
})(jQuery);

(function ($) {
	"use strict";

	qodefCore.shortcodes.lucent_core_accordion = {};

	$(document).ready(function () {
		qodefAccordion.init();
	});
	
	var qodefAccordion = {
		init: function () {
			this.holder = $('.qodef-accordion');
			
			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this);
					
					if ($thisHolder.hasClass('qodef-behavior--accordion')) {
						qodefAccordion.initAccordion($thisHolder);
					}
					
					if ($thisHolder.hasClass('qodef-behavior--toggle')) {
						qodefAccordion.initToggle($thisHolder);
					}
					
					$thisHolder.addClass('qodef--init');
				});
			}
		},
		initAccordion: function ($accordion) {
			$accordion.accordion({
				animate: "swing",
				collapsible: true,
				active: 0,
				icons: "",
				heightStyle: "content"
			});
		},
		initToggle: function ($toggle) {
			var $toggleAccordionTitle = $toggle.find('.qodef-accordion-title'),
				$toggleAccordionContent = $toggleAccordionTitle.next();
			
			$toggle.addClass("accordion ui-accordion ui-accordion-icons ui-widget ui-helper-reset");
			$toggleAccordionTitle.addClass("ui-accordion-header ui-state-default ui-corner-top ui-corner-bottom");
			$toggleAccordionContent.addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom").hide();
			
			$toggleAccordionTitle.each(function () {
				var $thisTitle = $(this);
				
				$thisTitle.hover(function () {
					$thisTitle.toggleClass("ui-state-hover");
				});
				
				$thisTitle.on('click', function () {
					$thisTitle.toggleClass('ui-accordion-header-active ui-state-active ui-state-default ui-corner-bottom');
					$thisTitle.next().toggleClass('ui-accordion-content-active').slideToggle(400);
				});
			});
		}
	};

	qodefCore.shortcodes.lucent_core_accordion.qodefAccordion = qodefAccordion;

})(jQuery);

(function ($) {
	"use strict";

	qodefCore.shortcodes.lucent_core_button = {};

	$(document).ready(function () {
		qodefButton.init();
	});
	
	var qodefButton = {
		init: function () {
			this.buttons = $('.qodef-button');
			
			if (this.buttons.length) {
				this.buttons.each(function () {
					var $thisButton = $(this);
					
					qodefButton.buttonHoverColor($thisButton);
					qodefButton.buttonHoverBgColor($thisButton);
					qodefButton.buttonHoverBorderColor($thisButton);
				});
			}
		},
		buttonHoverColor: function ($button) {
			if (typeof $button.data('hover-color') !== 'undefined') {
				var hoverColor = $button.data('hover-color');
				var originalColor = $button.css('color');
				
				$button.on('mouseenter', function () {
					qodefButton.changeColor($button, 'color', hoverColor);
				});
				$button.on('mouseleave', function () {
					qodefButton.changeColor($button, 'color', originalColor);
				});
			}
		},
		buttonHoverBgColor: function ($button) {
			if (typeof $button.data('hover-background-color') !== 'undefined') {
				var hoverBackgroundColor = $button.data('hover-background-color');
				var originalBackgroundColor = $button.css('background-color');
				
				$button.on('mouseenter', function () {
					qodefButton.changeColor($button, 'background-color', hoverBackgroundColor);
				});
				$button.on('mouseleave', function () {
					qodefButton.changeColor($button, 'background-color', originalBackgroundColor);
				});
			}
		},
		buttonHoverBorderColor: function ($button) {
			if (typeof $button.data('hover-border-color') !== 'undefined') {
				var hoverBorderColor = $button.data('hover-border-color');
				var originalBorderColor = $button.css('borderTopColor');
				
				$button.on('mouseenter', function () {
					qodefButton.changeColor($button, 'border-color', hoverBorderColor);
				});
				$button.on('mouseleave', function () {
					qodefButton.changeColor($button, 'border-color', originalBorderColor);
				});
			}
		},
		changeColor: function ($button, cssProperty, color) {
			$button.css(cssProperty, color);
		}
	};

	qodefCore.shortcodes.lucent_core_button.qodefButton = qodefButton;


})(jQuery);
(function ($) {
	"use strict";

	qodefCore.shortcodes.lucent_core_countdown = {};

	$(document).ready(function () {
		qodefCountdown.init();
	});
	
	var qodefCountdown = {
		init: function () {
			this.countdowns = $('.qodef-countdown');
			
			if (this.countdowns.length) {
				this.countdowns.each(function () {
					var $thisCountdown = $(this),
						$countdownElement = $thisCountdown.find('.qodef-m-date'),
						options = qodefCountdown.generateOptions($thisCountdown);
					
					qodefCountdown.initCountdown($countdownElement, options);
				});
			}
		},
		generateOptions: function($countdown) {
			var options = {};
			options.date = typeof $countdown.data('date') !== 'undefined' ? $countdown.data('date') : null;
			
			options.weekLabel = typeof $countdown.data('week-label') !== 'undefined' ? $countdown.data('week-label') : '';
			options.weekLabelPlural = typeof $countdown.data('week-label-plural') !== 'undefined' ? $countdown.data('week-label-plural') : '';
			
			options.dayLabel = typeof $countdown.data('day-label') !== 'undefined' ? $countdown.data('day-label') : '';
			options.dayLabelPlural = typeof $countdown.data('day-label-plural') !== 'undefined' ? $countdown.data('day-label-plural') : '';
			
			options.hourLabel = typeof $countdown.data('hour-label') !== 'undefined' ? $countdown.data('hour-label') : '';
			options.hourLabelPlural = typeof $countdown.data('hour-label-plural') !== 'undefined' ? $countdown.data('hour-label-plural') : '';
			
			options.minuteLabel = typeof $countdown.data('minute-label') !== 'undefined' ? $countdown.data('minute-label') : '';
			options.minuteLabelPlural = typeof $countdown.data('minute-label-plural') !== 'undefined' ? $countdown.data('minute-label-plural') : '';
			
			options.secondLabel = typeof $countdown.data('second-label') !== 'undefined' ? $countdown.data('second-label') : '';
			options.secondLabelPlural = typeof $countdown.data('second-label-plural') !== 'undefined' ? $countdown.data('second-label-plural') : '';
			
			return options;
		},
		initCountdown: function ($countdownElement, options) {
			var $weekHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%w</span><span class="qodef-label">' + '%!w:' + options.weekLabel + ',' + options.weekLabelPlural + ';</span></span>';
			var $dayHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%d</span><span class="qodef-label">' + '%!d:' + options.dayLabel + ',' + options.dayLabelPlural + ';</span></span>';
			var $hourHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%H</span><span class="qodef-label">' + '%!H:' + options.hourLabel + ',' + options.hourLabelPlural + ';</span></span>';
			var $minuteHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%M</span><span class="qodef-label">' + '%!M:' + options.minuteLabel + ',' + options.minuteLabelPlural + ';</span></span>';
			var $secondHTML = '<span class="qodef-digit-wrapper"><span class="qodef-digit">%S</span><span class="qodef-label">' + '%!S:' + options.secondLabel + ',' + options.secondLabelPlural + ';</span></span>';
			
			$countdownElement.countdown(options.date, function(event) {
				$(this).html(event.strftime($weekHTML + $dayHTML + $hourHTML + $minuteHTML + $secondHTML));
			});
		}
	};

	qodefCore.shortcodes.lucent_core_countdown.qodefCountdown  = qodefCountdown;


})(jQuery);
(function ($) {
	"use strict";

	qodefCore.shortcodes.lucent_core_counter = {};

	$(document).ready(function () {
		qodefCounter.init();
	});
	
	var qodefCounter = {
		init: function () {
			this.counters = $('.qodef-counter');
			
			if (this.counters.length) {
				this.counters.each(function () {
					var $thisCounter = $(this),
						$counterElement = $thisCounter.find('.qodef-m-digit'),
						options = qodefCounter.generateOptions($thisCounter);
					
					qodefCounter.counterScript($counterElement, options);
				});
			}
		},
		generateOptions: function($counter) {
			var options = {};
			options.start = typeof $counter.data('start-digit') !== 'undefined' && $counter.data('start-digit') !== '' ? $counter.data('start-digit') : 0;
			options.end = typeof $counter.data('end-digit') !== 'undefined' && $counter.data('end-digit') !== '' ? $counter.data('end-digit') : null;
			options.step = typeof $counter.data('step-digit') !== 'undefined' && $counter.data('step-digit') !== '' ? $counter.data('step-digit') : 1;
			options.delay = typeof $counter.data('step-delay') !== 'undefined' && $counter.data('step-delay') !== '' ? parseInt( $counter.data('step-delay'), 10 ) : 100;
			options.txt = typeof $counter.data('digit-label') !== 'undefined' && $counter.data('digit-label') !== '' ? $counter.data('digit-label') : '';
			
			return options;
		},
		counterScript: function ($counterElement, options) {
			var defaults = {
				start: 0,
				end: null,
				step: 1,
				delay: 50,
				txt: ""
			};
			
			var settings = $.extend(defaults, options || {});
			var nb_start = settings.start;
			var nb_end = settings.end;
			
			$counterElement.text(nb_start + settings.txt);
			
			var counter = function() {
				// Definition of conditions of arrest
				if (nb_end !== null && nb_start >= nb_end) {
					return;
				}
				// incrementation
				nb_start = nb_start + settings.step;
				
				if( nb_start >= nb_end ) {
					nb_start = nb_end;
				}
				// display
				$counterElement.text(nb_start + settings.txt);
			};
			
			// Timer
			// Launches every "settings.delay"
			$counterElement.appear(function() {
				setInterval(counter, settings.delay);
			}, { accX: 0, accY: 0 });
		}
	};

	qodefCore.shortcodes.lucent_core_counter.qodefCounter  = qodefCounter;

})(jQuery);
(function ($) {
	"use strict";

    qodefCore.shortcodes.lucent_core_dual_image_with_text = {};

	$(document).ready(function () {
		qodefParallaxDualImage.init();
	});
	
	var qodefParallaxDualImage = {
		init: function () {
			var parallaxIntances = $("[data-parallax]");
			
			if (parallaxIntances.length && !$('html').hasClass('touch')) {
				ParallaxScroll.init(); //initialzation removed from plugin js file to have it run only on non-touch devices
			}
			
			this.holder = $('.qodef-dual-image-with-text:odd');
			
			if (this.holder.length) {
				
				this.holder.each(function () {
					
					var holder = $(this);
					
					holder.find('.qodef-image--one .qodef-m-image-inner').css({'transition-delay': '.5s'});
					holder.find('.qodef-image--two .qodef-m-image-inner').css({'transition-delay': '.8s'});
				});
			}
		}
	};

    qodefCore.shortcodes.lucent_core_dual_image_with_text.qodefParallaxDualImage = qodefParallaxDualImage;
    qodefCore.shortcodes.lucent_core_dual_image_with_text.qodefAppear = qodef.qodefAppear;
	
})(jQuery);
(function ($) {
	"use strict";
	
	qodefCore.shortcodes.lucent_core_google_map = {};
	
	$(document).ready(function () {
		qodefGoogleMap.init();
	});
	
	var qodefGoogleMap = {
		init: function () {
			this.holder = $('.qodef-google-map');
			
			if (this.holder.length) {
				this.holder.each(function () {
					if (typeof window.qodefGoogleMap !== 'undefined') {
						window.qodefGoogleMap.initMap($(this).find('.qodef-m-map'));
					}
				});
			}
		}
	};
	
	qodefCore.shortcodes.lucent_core_google_map.qodefGoogleMap = qodefGoogleMap;
	
})(jQuery);
(function ($) {
    "use strict";

	qodefCore.shortcodes.lucent_core_icon = {};

    $(document).ready(function () {
        qodefIcon.init();
    });

    var qodefIcon = {
        init: function () {
            this.icons = $('.qodef-icon-holder');

            if (this.icons.length) {
                this.icons.each(function () {
                    var $thisIcon = $(this);

                    qodefIcon.iconHoverColor($thisIcon);
                    qodefIcon.iconHoverBgColor($thisIcon);
                    qodefIcon.iconHoverBorderColor($thisIcon);
                });
            }
        },
        iconHoverColor: function ($iconHolder) {
            if (typeof $iconHolder.data('hover-color') !== 'undefined') {
                var spanHolder = $iconHolder.find('span');
                var originalColor = spanHolder.css('color');
                var hoverColor = $iconHolder.data('hover-color');

                $iconHolder.on('mouseenter', function () {
                    qodefIcon.changeColor(spanHolder, 'color', hoverColor);
                });
                $iconHolder.on('mouseleave', function () {
                    qodefIcon.changeColor(spanHolder, 'color', originalColor);
                });
            }
        },
        iconHoverBgColor: function ($iconHolder) {
            if (typeof $iconHolder.data('hover-background-color') !== 'undefined') {
                var hoverBackgroundColor = $iconHolder.data('hover-background-color');
                var originalBackgroundColor = $iconHolder.css('background-color');

                $iconHolder.on('mouseenter', function () {
                    qodefIcon.changeColor($iconHolder, 'background-color', hoverBackgroundColor);
                });
                $iconHolder.on('mouseleave', function () {
                    qodefIcon.changeColor($iconHolder, 'background-color', originalBackgroundColor);
                });
            }
        },
        iconHoverBorderColor: function ($iconHolder) {
            if (typeof $iconHolder.data('hover-border-color') !== 'undefined') {
                var hoverBorderColor = $iconHolder.data('hover-border-color');
                var originalBorderColor = $iconHolder.css('borderTopColor');

                $iconHolder.on('mouseenter', function () {
                    qodefIcon.changeColor($iconHolder, 'border-color', hoverBorderColor);
                });
                $iconHolder.on('mouseleave', function () {
                    qodefIcon.changeColor($iconHolder, 'border-color', originalBorderColor);
                });
            }
        },
        changeColor: function (iconElement, cssProperty, color) {
            iconElement.css(cssProperty, color);
        }
    };

	qodefCore.shortcodes.lucent_core_icon.qodefIcon = qodefIcon;

})(jQuery);
(function ($) {
	"use strict";

	qodefCore.shortcodes.lucent_core_dual_image_slider = {};

	$(document).ready(function () {
		qodefDualImageSlider.init();
	});
	
	var qodefDualImageSlider = {
		init: function () {
			this.holder = $('.qodef-dual-image-slider');
			
			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this);
					qodefDualImageSlider.createSlider($thisHolder);
					qodefDualImageSlider.fullHeightSliderCalc($thisHolder);

					$(window).resize(function () {
						qodefDualImageSlider.fullHeightSliderCalc($thisHolder);
					});
				});
			}
		},
		createSlider: function ($holder) {
			var $swiperHolder = $holder.find('.qodef-m-image-holder');
			var $paginationHolder = $holder.find('.swiper-pagination');
			var $thumbnailsHolder = $holder.find('.qodef-m-thumbnails-holder');
            var $headlineHolder = $holder.find('.qodef-m-headline');

            var sliderOptions = typeof $swiperHolder.data('options') !== 'undefined' ? $swiperHolder.data('options') : {},
                slidesPerView = 1,
                loop = sliderOptions.loop !== undefined && sliderOptions.loop !== '' ? sliderOptions.loop : true,
                autoplay = sliderOptions.autoplay !== undefined && sliderOptions.autoplay !== '' ? sliderOptions.autoplay : true,
                speed = sliderOptions.speed !== undefined && sliderOptions.speed !== '' ? parseInt(sliderOptions.speed, 10) : 5000,
                speedAnimation = sliderOptions.speedAnimation !== undefined && sliderOptions.speedAnimation !== '' ? parseInt(sliderOptions.speedAnimation, 10) : 1000,
                spaceBetween = 0,
                centeredSlides = false,
                nextNavigation = $holder.find('.swiper-button-next'),
                prevNavigation = $holder.find('.swiper-button-prev');

            if (autoplay === true) {
                autoplay = {
                    delay: speed,
                    disableOnInteraction: false
                };
            }

			var $swiper = new Swiper($swiperHolder, {
				slidesPerView: slidesPerView,
				centeredSlides: centeredSlides,
				spaceBetween: spaceBetween,
				autoplay: autoplay,
				loop: loop,
				speed: speedAnimation,
                navigation: {nextEl: nextNavigation, prevEl: prevNavigation},
                pagination: {
                    el: $paginationHolder,
                    clickable: true,
                    bulletClass: 'qodef-m-number',
                    renderBullet: function (index, className) {
                        return '<span class="' + className + '"><span>' + (index + 1) + '</span></span>';
                    },
                },
				on: {
					init: function () {
						$swiperHolder.addClass('qodef-swiper--initialized');

                        setTimeout(function() {
                            var paginationWidth = $holder.find('.swiper-pagination').outerWidth();
                            var headline = $holder.find('.qodef-m-headline');

                            headline.each(function () {
                                $(this).css('left', paginationWidth + 35);
                            });

							$holder.addClass('qodef--init');
                        }, 500);
					},
					slideChange: function slideChange() {
						var swiper = this;
						var activeIndex = swiper.activeIndex;
					}
				}
			});
		},
		fullHeightSliderCalc: function ($holder) {
			var windowHeight = (window.innerHeight || document.documentElement.clientHeight);
			var sliderHeight = '';

			if ( $holder.hasClass('qodef-full-height-slider--yes') && qodefCore.windowWidth > 1024 ) {
				sliderHeight = windowHeight - qodefGlobal.vars.headerHeight - qodefGlobal.vars.topAreaHeight - qodefGlobal.vars.adminBarHeight;

				if (qodefCore.body.hasClass('qodef--passepartout')) {
					var passepartoutSize = parseInt(qodefCore.body.css('padding-top'));

					sliderHeight -= passepartoutSize;
				}

			} else if ( $holder.hasClass('qodef-full-height-slider--yes') && qodefCore.windowWidth <= 1024 ) {
				sliderHeight = windowHeight - qodefGlobal.vars.mobileHeaderHeight - qodefGlobal.vars.adminBarHeight;
			} else {
				sliderHeight = 'auto';
			}

			$holder.height(sliderHeight);
		}
	};

	qodefCore.shortcodes.lucent_core_dual_image_slider.qodefDualImageSlider = qodefDualImageSlider;

})(jQuery);

(function ($) {
    "use strict";

	qodefCore.shortcodes.lucent_core_image_with_active_scene = {};

    $(document).ready(function () {
        qodefImageWithActiveScene.init();
    });

    var qodefImageWithActiveScene = {
        init: function () {
            var $holder = $('.qodef-image-with-active-scene.qodef--has-appear.qodef--has-background');

            if ( $holder.length ) {
                $holder.each( function () {
                    var $thisHolder = $(this);

                    qodefImageWithActiveScene.setParallaxData( $thisHolder );
                })
            }
        },
        setParallaxData: function ( $holder ) {
            var $image = $holder.find('.qodef-absolute-image > img');

            if ( $image.length ) {
                $image.attr('data-parallax', '{"y": -50, "smoothness": 200}');
            }

            if ( $holder.hasClass('qodef-animation--right') ) {

                if ( $image.length ) {
                    $image.attr('data-parallax', '{"y": -25, "smoothness": 200}');
                }
            }

            setTimeout( function () {
                qodefImageWithActiveScene.initParallax();
            }, 100);
        },
        initParallax: function () {
            var $parallaxIntances = $("[data-parallax]");

            if ( $parallaxIntances.length && !qodef.html.hasClass('touch') ) {
                ParallaxScroll.init();
            }
        }
    };

    qodefCore.shortcodes.lucent_core_image_with_active_scene.qodefImageWithActiveScene = qodefImageWithActiveScene;
    qodefCore.shortcodes.lucent_core_image_with_active_scene.qodefMagnificPopup = qodef.qodefMagnificPopup;

})(jQuery);

(function ($) {
    "use strict";
    
	qodefCore.shortcodes.lucent_core_image_gallery = {};
	qodefCore.shortcodes.lucent_core_image_gallery.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.lucent_core_image_gallery.qodefMasonryLayout = qodef.qodefMasonryLayout;

})(jQuery);
(function ($) {
    "use strict";

	qodefCore.shortcodes.lucent_core_image_with_text = {};
    qodefCore.shortcodes.lucent_core_image_with_text.qodefMagnificPopup = qodef.qodefMagnificPopup;

})(jQuery);
(function($) {
	"use strict";

    qodefCore.shortcodes.lucent_core_preview_slider = {};

    $( window ).on(
        'load',
        function () {
        qodefPreviewSlider.init();
    });

    var qodefPreviewSlider = {
        init: function () {

            var sliders = $('.qodef-preview-slider');
            sliders.each(function() {

                var slider = $(this);

                var autoplay = false,
                    autoPlaySpeed = 2000;

                if(typeof slider.data('autoplay') !== 'undefined' && slider.data('autoplay') == 'yes'){
                    autoplay = true;
                }

                if(typeof slider.data('autoplay-speed') !== 'undefined' && slider.data('autoplay-speed') !== ''){
                    autoPlaySpeed = slider.data('autoplay-speed');
                }

                var slickImages = {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    speed: 1000,
                    autoplay: autoplay,
                    autoplaySpeed: autoPlaySpeed,
                    arrows: false,
                    vertical: true,
                    useCSS: false,
                    easing: 'easeInOutCubic',
                    draggable: false,
                    infinite: true,
                    pauseOnHover: false
                };

                if($('#qodef-landing-rev-holder').length) {
                    var $interval = setInterval( function () {
                        if ( qodefCore.body.hasClass('qodef--preloder-end') ) {
                            setTimeout( function () {
                                var tabletSlider = slider.find('.qodef-ps-tablet-images').slick(slickImages);
                                slider.find('.qodef-ps-tablet-holder').css({'opacity': 1, 'transform': 'translateY(0)'});

                                var laptopSlider = slider.find('.qodef-ps-laptop-images').slick(slickImages);
                                slider.find('.qodef-ps-laptop-holder').css({'opacity': 1, 'transform': 'translateY(0)'});

                                var mobileSlider = slider.find('.qodef-ps-mobile-images').slick(slickImages);
                                slider.find('.qodef-ps-mobile-holder').css({'opacity': 1, 'transform': 'translateY(0)'});
                            }, 300);

                            clearInterval($interval);
                        }
                    }, 100);
                } else {
                    slider.appear(function () {
                        setTimeout( function () {
                            var tabletSlider = slider.find('.qodef-ps-tablet-images').slick(slickImages);
                            slider.find('.qodef-ps-tablet-holder').css({'opacity': 1, 'transform': 'translateY(0)'});

                            var laptopSlider = slider.find('.qodef-ps-laptop-images').slick(slickImages);
                            slider.find('.qodef-ps-laptop-holder').css({'opacity': 1, 'transform': 'translateY(0)'});

                            var mobileSlider = slider.find('.qodef-ps-mobile-images').slick(slickImages);
                            slider.find('.qodef-ps-mobile-holder').css({'opacity': 1, 'transform': 'translateY(0)'});
                        }, 300);
                    }, {accX: 0, accY: -100});
                }
                slider.addClass('qodef-preview-slider-loaded');
            });
        }
    };

    qodefCore.shortcodes.lucent_core_preview_slider.qodefPreviewSlider = qodefPreviewSlider;
	
})(jQuery);

(function ($) {
    'use strict';

    qodefCore.shortcodes.lucent_core_progress_bar = {};

    $(document).ready(function () {
        qodefProgressBar.init();
    });

    /**
     * Init progress bar shortcode functionality
     */
    var qodefProgressBar = {
        init: function () {
            this.holder = $('.qodef-progress-bar');

            if (this.holder.length) {
                this.holder.each(function () {
                    var $thisHolder = $(this),
                        layout = $thisHolder.data('layout');

                    $thisHolder.appear(function () {
                        $thisHolder.addClass('qodef--init');

                        var $container = $thisHolder.find('.qodef-m-canvas'),
                            data = qodefProgressBar.generateBarData($thisHolder, layout),
                            number = $thisHolder.data('number') / 100;

                        switch (layout) {
                            case 'circle':
                                qodefProgressBar.initCircleBar($container, data, number);
                                break;
                            case 'semi-circle':
                                qodefProgressBar.initSemiCircleBar($container, data, number);
                                break;
                            case 'line':
                                data = qodefProgressBar.generateLineData($thisHolder, number);
                                qodefProgressBar.initLineBar($container, data);
                                break;
                            case 'custom':
                                qodefProgressBar.initCustomBar($container, data, number);
                                break;
                        }
                    });
                });
            }
        },
        generateBarData: function (thisBar, layout) {
            var activeWidth = thisBar.data('active-line-width');
            var activeColor = thisBar.data('active-line-color');
            var inactiveWidth = thisBar.data('inactive-line-width');
            var inactiveColor = thisBar.data('inactive-line-color');
            var easing = 'linear';
            var duration = typeof thisBar.data('duration') !== 'undefined' && thisBar.data('duration') !== '' ? parseInt(thisBar.data('duration'), 10) : 1600;
            var textColor = thisBar.data('text-color');

            return {
                strokeWidth: activeWidth,
                color: activeColor,
                trailWidth: inactiveWidth,
                trailColor: inactiveColor,
                easing: easing,
                duration: duration,
                svgStyle: {
                    width: '100%',
                    height: '100%'
                },
                text: {
                    style: {
                        color: textColor
                    },
                    autoStyleContainer: false
                },
                from: {
                    color: inactiveColor
                },
                to: {
                    color: activeColor
                },
                step: function (state, bar) {
                    if (layout !== 'custom') {
                        bar.setText(Math.round(bar.value() * 100) + '%');
                    }
                }
            };
        },
        generateLineData: function (thisBar, number) {
            var height = thisBar.data('active-line-width');
            var activeColor = thisBar.data('active-line-color');
            var inactiveHeight = thisBar.data('inactive-line-width');
            var inactiveColor = thisBar.data('inactive-line-color');
            var duration = typeof thisBar.data('duration') !== 'undefined' && thisBar.data('duration') !== '' ? parseInt(thisBar.data('duration'), 10) : 1600;
            var textColor = thisBar.data('text-color');

            return {
                percentage: number * 100,
                duration: duration,
                fillBackgroundColor: activeColor,
                backgroundColor: inactiveColor,
                height: height,
                inactiveHeight: inactiveHeight,
                followText: thisBar.hasClass('qodef-percentage--floating'),
                textColor: textColor
            };
        },
        initCircleBar: function ($container, data, number) {
            if (qodefProgressBar.checkBar($container)) {
                var $bar = new ProgressBar.Circle($container[0], data);

                $bar.animate(number);
            }
        },
        initSemiCircleBar: function ($container, data, number) {
            if (qodefProgressBar.checkBar($container)) {
                var $bar = new ProgressBar.SemiCircle($container[0], data);

                $bar.animate(number);
            }
        },
        initCustomBar: function ($container, data, number) {
            if (qodefProgressBar.checkBar($container)) {
                var $bar = new ProgressBar.Path($container[0], data);

                $bar.set(0);
                $bar.animate(number);
            }
        },
        initLineBar: function ($container, data) {
            $container.LineProgressbar(data);
        },
        checkBar: function ($container) {
            // check if svg is already in container, elementor fix
            if ($container.find('svg').length) {
                return false;
            }

            return true;
        }
    };

    qodefCore.shortcodes.lucent_core_progress_bar.qodefProgressBar = qodefProgressBar;

})(jQuery);
(function ($) {
	"use strict";

	qodefCore.shortcodes.lucent_core_tabs = {};

	$(document).ready(function () {
		qodefTabs.init();
	});
	
	var qodefTabs = {
		init: function () {
			this.holder = $('.qodef-tabs');
			
			if (this.holder.length) {
				this.holder.each(function () {
					qodefTabs.initTabs($(this));
				});
			}
		},
		initTabs: function ($tabs) {
			$tabs.children('.qodef-tabs-content').each(function (index) {
				index = index + 1;
				
				var $that = $(this),
					link = $that.attr('id'),
					$navItem = $that.parent().find('.qodef-tabs-navigation li:nth-child(' + index + ') a'),
					navLink = $navItem.attr('href');
				
				link = '#' + link;
				
				if (link.indexOf(navLink) > -1) {
					$navItem.attr('href', link);
				}
			});
			
			$tabs.addClass('qodef--init').tabs();
		}
	};

	qodefCore.shortcodes.lucent_core_tabs.qodefTabs = qodefTabs;

})(jQuery);
(function ($) {
    "use strict";

	qodefCore.shortcodes.lucent_core_team_single = {};
    qodefCore.shortcodes.lucent_core_team_single.qodefMagnificPopup = qodef.qodefMagnificPopup;

})(jQuery);

(function ($) {
    "use strict";

	qodefCore.shortcodes.lucent_core_video_button = {};
    qodefCore.shortcodes.lucent_core_video_button.qodefMagnificPopup = qodef.qodefMagnificPopup;

})(jQuery);
(function ($) {
	"use strict";

	$( window ).on(
		'load',
		function () {
		qodefStickySidebar.init();
	});
	
	var qodefStickySidebar = {
		init: function () {
			var info = $('.widget_lucent_core_sticky_sidebar');
			
			if (info.length && qodefCore.windowWidth > 1024) {
				info.wrapper = info.parents('#qodef-page-sidebar');
				info.c = 24;
				info.offsetM = info.offset().top - info.wrapper.offset().top;
				info.adj = 15;
				
				qodefStickySidebar.callStack(info);
				
				$(window).on('resize', function () {
					if (qodefCore.windowWidth > 1024) {
						qodefStickySidebar.callStack(info);
					}
				});
				
				$(window).on('scroll', function () {
					if (qodefCore.windowWidth > 1024) {
						qodefStickySidebar.infoPosition(info);
					}
				});
			}
		},
		calc: function (info) {
			var content = $('.qodef-page-content-section'),
				headerH = qodefCore.body.hasClass('qodef-header-appearance--none') ? 0 : parseInt(qodefGlobal.vars.headerHeight, 10);
			
			info.start = content.offset().top;
			info.end = content.outerHeight();
			info.h = info.wrapper.height();
			info.w = info.outerWidth();
			info.left = info.offset().left;
			info.top = headerH + qodefGlobal.vars.adminBarHeight + info.c - info.offsetM;
			info.data('state', 'top');
		},
		infoPosition: function (info) {
			if (qodefCore.scroll < info.start - info.top && qodefCore.scroll + info.h && info.data('state') !== 'top') {
				TweenMax.to(info.wrapper, .1, {
					y: 5,
				});
				TweenMax.to(info.wrapper, .3, {
					y: 0,
					delay: .1,
				});
				info.data('state', 'top');
				info.wrapper.css({
					'position': 'static',
				});
			} else if (qodefCore.scroll >= info.start - info.top && qodefCore.scroll + info.h + info.adj <= info.start + info.end &&
				info.data('state') !== 'fixed') {
				var c = info.data('state') === 'top' ? 1 : -1;
				info.data('state', 'fixed');
				info.wrapper.css({
					'position': 'fixed',
					'top': info.top,
					'left': info.left,
					'width': info.w
				});
				TweenMax.fromTo(info.wrapper, .2, {
					y: 0
				}, {
					y: c * 10,
					ease: Power4.easeInOut
				});
				TweenMax.to(info.wrapper, .2, {
					y: 0,
					delay: .2,
				});
			} else if (qodefCore.scroll + info.h + info.adj > info.start + info.end && info.data('state') !== 'bottom') {
				info.data('state', 'bottom');
				info.wrapper.css({
					'position': 'absolute',
					'top': info.end - info.h - info.adj,
					'left': 0,
				});
				TweenMax.fromTo(info.wrapper, .1, {
					y: 0
				}, {
					y: -5,
				});
				TweenMax.to(info.wrapper, .3, {
					y: 0,
					delay: .1,
				});
			}
		},
		callStack: function (info) {
			this.calc(info);
			this.infoPosition(info);
		}
	};
	
})(jQuery);

(function ($) {
    "use strict";

    $(document).ready(function () {
        qodefSearchPostTypeWidget.init();
        qodefSearchPostTypeFullscreen.init();
    });

    var qodefSearchPostTypeWidget = {
        init: function () {
            var searchPostTypeHolder = $('.qodef-search-post-type');

            if (searchPostTypeHolder.length) {
                searchPostTypeHolder.each(function () {
                    var thisSearch = $(this),
                        searchField = thisSearch.find('.qodef-post-type-search-field'),
                        resultsHolder = thisSearch.find('.qodef-post-type-search-results'),
                        searchLoading = thisSearch.find('.qodef-search-loading'),
                        searchIcon = thisSearch.find('.qodef-search-icon');

                    searchLoading.addClass('qodef-hidden');

                    var postType = thisSearch.data('post-type'),
                        keyPressTimeout;

                    searchField.on('keyup paste', function() {
                        var field = $(this);
                        field.attr('autocomplete','off');
                        searchLoading.removeClass('qodef-hidden');
                        searchIcon.addClass('qodef-hidden');
                        clearTimeout(keyPressTimeout);

                        keyPressTimeout = setTimeout( function() {
                            var searchTerm = field.val();

                            if(searchTerm.length < 3) {
                                resultsHolder.html('');
                                resultsHolder.fadeOut();
                                searchLoading.addClass('qodef-hidden');
                                searchIcon.removeClass('qodef-hidden');
                            } else {
                                var unique_num = $('input[name="qodef_unique_num"]').val();
                                var ajaxData = {
                                    action: 'lucent_core_search_post_types',
                                    term: searchTerm,
                                    postType: postType,
                                    unique_num: $('input[name="qodef_unique_num"]').val(),
                                    search_post_types_nonce: $('input[name="qodef_search_post_types_nonce_' + unique_num + '"]').val()
                                };

                                $.ajax({
                                    type: 'POST',
                                    data: ajaxData,
                                    url: qodefGlobal.vars.qodefAjaxUrl,
                                    success: function (data) {
                                        var response = JSON.parse(data);
                                        if (response.status === 'success') {
                                            searchLoading.addClass('qodef-hidden');
                                            searchIcon.removeClass('qodef-hidden');
                                            resultsHolder.html(response.data.html);
                                            resultsHolder.fadeIn();
                                        }
                                    },
                                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                                        console.log("Status: " + textStatus);
                                        console.log("Error: " + errorThrown);
                                        searchLoading.addClass('qodef-hidden');
                                        searchIcon.removeClass('qodef-hidden');
                                        resultsHolder.fadeOut();
                                    }
                                });
                            }
                        }, 500);
                    });

                    searchField.on('focusout', function () {
                        searchLoading.addClass('qodef-hidden');
                        searchIcon.removeClass('qodef-hidden');
                        resultsHolder.fadeOut();
                    });
                });
            }

        },
    };

    var qodefSearchPostTypeFullscreen = {
        init: function(){
            var $searchHolderOuter = $('.qodef-search-post-type.full-screen');

            if ($searchHolderOuter.length ) {

                $searchHolderOuter.each(function () {
                    var $thisHolder = $(this),
                        $searchOpener = $thisHolder.find('.qodef-search-post-type-full-screen-search-opener'),
                        $searchHolder = $thisHolder.find('.qodef-search-post-type-full-screen-search-holder'),
                        $searchClose = $searchHolder.find('.qodef-close-icon');

                    //qodefCore.body.addClass('qodef-search-post-type-full-screen');

                    $searchOpener.on('click', function (e) {
                        e.preventDefault();
                        if($searchHolder.hasClass('qodef-search-post-type-full-screen--opened')){
                            qodefSearchPostTypeFullscreen.closeFullscreen($searchHolder);
                        }else{
                            qodefSearchPostTypeFullscreen.openFullscreen($searchHolder);
                        }
                    });
                    $searchClose.on('click', function (e) {
                        e.preventDefault();
                        qodefSearchPostTypeFullscreen.closeFullscreen($searchHolder);
                    });

                    //Close on escape
                    $(document).keyup(function (e) {
                        if (e.keyCode === 27 && $searchHolder.hasClass('qodef-search-post-type-full-screen--opened')) { //KeyCode for ESC button is 27
                            qodefSearchPostTypeFullscreen.closeFullscreen($searchHolder);
                        }
                    });


                });
            }
        },
        openFullscreen: function($searchHolder){
            $searchHolder.removeClass('qodef-search-post-type-full-screen--fadeout');
            $searchHolder.addClass('qodef-search-post-type-full-screen--opened qodef-search-post-type-full-screen--fadein');
            qodefCore.body.addClass('qodef-search-post-type-full-screen-body--opened');

            setTimeout(function () {
                $searchHolder.find('.qodef-m-form-field').focus();
            }, 900);

            qodefCore.qodefScroll.disable();
        },
        closeFullscreen: function($searchHolder){
            qodefCore.body.removeClass('qodef-search-post-type-full-screen-body--opened');
            $searchHolder.removeClass('qodef-search-post-type-full-screen--opened qodef-search-post-type-full-screen--fadein');
            $searchHolder.addClass('qodef-search-post-type-full-screen--fadeout');

            setTimeout(function () {
                $searchHolder.find('.qodef-m-form-field').val('');
                $searchHolder.find('.qodef-m-form-field').blur();
                qodefCore.body.removeClass('qodef-search-post-type-full-screen--fadeout');
            }, 300);

            qodefCore.qodefScroll.enable();
        }
    };

})(jQuery);

(function ($) {
	"use strict";
	
	var shortcode = 'lucent_core_blog_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}

	$(document).ready(function () {
		qodefBlogList.init();
	});

	var qodefBlogList = {
		init: function () {
			this.holder = $('.qodef-blog.qodef-item-layout--classic, .qodef-blog.qodef-item-layout--standard, .archive .qodef-blog.qodef--list');

			if ( this.holder.length ) {
				this.holder.each( function () {
					var $thisHolder = $(this);

					qodefBlogList.linkHover( $thisHolder );
				});
			}
		},
		linkHover: function ( $holder ) {
			var $item = $holder.find('.qodef-blog-item');

			$item.each( function() {
				var $thisItem = $(this),
					$itemImage = $thisItem.find('.qodef-e-media'),
					$titleLink = $thisItem.find('.qodef-e-title-link');

				$itemImage.on('mouseenter', function() {
					$itemImage.closest('.qodef-blog-item').addClass('qodef--active');
				});

				$titleLink.on('mouseenter', function() {
					$titleLink.closest('.qodef-blog-item').addClass('qodef--active');
				});

				$itemImage.on('mouseleave', function() {
					$itemImage.closest('.qodef-blog-item').removeClass('qodef--active');
				});

				$titleLink.on('mouseleave', function() {
					$titleLink.closest('.qodef-blog-item').removeClass('qodef--active');
				});
			})
		},
	}
	
})(jQuery);
(function ($) {
	"use strict";
	
	var fixedHeaderAppearance = {
		showHideHeader: function ($pageOuter, $header) {
			if (qodefCore.windowWidth > 1024) {
				if (qodefCore.scroll <= 0) {
					qodefCore.body.removeClass('qodef-header--fixed-display');
					$pageOuter.css('padding-top', '0');
					$header.css('margin-top', '0');
				} else {
					qodefCore.body.addClass('qodef-header--fixed-display');
					$pageOuter.css('padding-top', parseInt(qodefGlobal.vars.headerHeight + qodefGlobal.vars.topAreaHeight) + 'px');
					$header.css('margin-top', parseInt(qodefGlobal.vars.topAreaHeight) + 'px');
				}
			}
		},
		init: function () {
            
            if (!qodefCore.body.hasClass('qodef-header--vertical')) {
                var $pageOuter = $('#qodef-page-outer'),
                    $header = $('#qodef-page-header');
                
                fixedHeaderAppearance.showHideHeader($pageOuter, $header);
                
                $(window).scroll(function () {
                    fixedHeaderAppearance.showHideHeader($pageOuter, $header);
                });
                
                $(window).resize(function () {
                    $pageOuter.css('padding-top', '0');
                    fixedHeaderAppearance.showHideHeader($pageOuter, $header);
                });
            }
		}
	};
	
	qodefCore.fixedHeaderAppearance = fixedHeaderAppearance.init;
	
})(jQuery);
(function ($) {
	"use strict";
	
	var stickyHeaderAppearance = {
		displayAmount: function () {
			if (qodefGlobal.vars.qodefStickyHeaderScrollAmount !== 0) {
				return parseInt(qodefGlobal.vars.qodefStickyHeaderScrollAmount, 10);
			} else {
				return parseInt(qodefGlobal.vars.headerHeight + qodefGlobal.vars.adminBarHeight, 10);
			}
		},
		showHideHeader: function (displayAmount) {
			
			if (qodefCore.scroll < displayAmount) {
				qodefCore.body.removeClass('qodef-header--sticky-display');
			} else {
				qodefCore.body.addClass('qodef-header--sticky-display');
			}
		},
		init: function () {
			var displayAmount = stickyHeaderAppearance.displayAmount();
			
			stickyHeaderAppearance.showHideHeader(displayAmount);
			$(window).scroll(function () {
				stickyHeaderAppearance.showHideHeader(displayAmount);
			});
		}
	};
	
	qodefCore.stickyHeaderAppearance = stickyHeaderAppearance.init;
	
})(jQuery);
(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefSearchCoversHeader.init();
	});
	
	var qodefSearchCoversHeader = {
		init: function () {
			var $searchOpener = $('a.qodef-search-opener'),
				$searchForm = $('.qodef-search-cover-form'),
				$searchClose = $searchForm.find('.qodef-m-close');
			
			if ($searchOpener.length && $searchForm.length) {
				$searchOpener.on('click', function (e) {
					e.preventDefault();
					qodefSearchCoversHeader.openCoversHeader($searchForm);
					
				});
				$searchClose.on('click', function (e) {
					e.preventDefault();
					qodefSearchCoversHeader.closeCoversHeader($searchForm);
				});
			}
		},
		openCoversHeader: function ($searchForm) {
			qodefCore.body.addClass('qodef-covers-search--opened qodef-covers-search--fadein');
			qodefCore.body.removeClass('qodef-covers-search--fadeout');
			
			setTimeout(function () {
				$searchForm.find('.qodef-m-form-field').focus();
			}, 600);
		},
		closeCoversHeader: function ($searchForm) {
			qodefCore.body.removeClass('qodef-covers-search--opened qodef-covers-search--fadein');
			qodefCore.body.addClass('qodef-covers-search--fadeout');
			
			setTimeout(function () {
				$searchForm.find('.qodef-m-form-field').val('');
				$searchForm.find('.qodef-m-form-field').blur();
				qodefCore.body.removeClass('qodef-covers-search--fadeout');
			}, 300);
		}
	};
	
})(jQuery);

(function ($) {
	"use strict";
	
	$(document).ready(function () {
        qodefSearch.init();
	});
	
	var qodefSearch = {
		init: function () {
            this.search = $('a.qodef-search-opener');

            if (this.search.length) {
                this.search.each(function () {
                    var $thisSearch = $(this);

                    qodefSearch.searchHoverColor($thisSearch);
                });
            }
        },
		searchHoverColor: function ($searchHolder) {
			if (typeof $searchHolder.data('hover-color') !== 'undefined') {
				var hoverColor = $searchHolder.data('hover-color'),
				    originalColor = $searchHolder.css('color');
				
				$searchHolder.on('mouseenter', function () {
					$searchHolder.css('color', hoverColor);
				}).on('mouseleave', function () {
					$searchHolder.css('color', originalColor);
				});
			}
		}
	};
	
})(jQuery);

(function($) {
    "use strict";

    $(document).ready(function(){
        qodefSearchFullscreen.init();
    });

	var qodefSearchFullscreen = {
	    init: function(){
            var $searchOpener = $('a.qodef-search-opener'),
                $searchHolder = $('.qodef-fullscreen-search-holder'),
                $searchClose = $searchHolder.find('.qodef-m-close');

            if ($searchOpener.length && $searchHolder.length) {
                $searchOpener.on('click', function (e) {
                    e.preventDefault();
                    if(qodefCore.body.hasClass('qodef-fullscreen-search--opened')){
                        qodefSearchFullscreen.closeFullscreen($searchHolder);
                    }else{
                        qodefSearchFullscreen.openFullscreen($searchHolder);
                    }
                });
                $searchClose.on('click', function (e) {
                    e.preventDefault();
                    qodefSearchFullscreen.closeFullscreen($searchHolder);
                });

                //Close on escape
                $(document).keyup(function (e) {
                    if (e.keyCode === 27 && qodefCore.body.hasClass('qodef-fullscreen-search--opened')) { //KeyCode for ESC button is 27
                        qodefSearchFullscreen.closeFullscreen($searchHolder);
                    }
                });
            }
        },
        openFullscreen: function($searchHolder){
            qodefCore.body.removeClass('qodef-fullscreen-search--fadeout');
            qodefCore.body.addClass('qodef-fullscreen-search--opened qodef-fullscreen-search--fadein');

            setTimeout(function () {
                $searchHolder.find('.qodef-m-form-field').focus();
            }, 900);

            qodefCore.qodefScroll.disable();
        },
        closeFullscreen: function($searchHolder){
            qodefCore.body.removeClass('qodef-fullscreen-search--opened qodef-fullscreen-search--fadein');
            qodefCore.body.addClass('qodef-fullscreen-search--fadeout');

            setTimeout(function () {
                $searchHolder.find('.qodef-m-form-field').val('');
                $searchHolder.find('.qodef-m-form-field').blur();
                qodefCore.body.removeClass('qodef-fullscreen-search--fadeout');
            }, 300);

            qodefCore.qodefScroll.enable();
        }
    };

})(jQuery);

(function ($) {
    "use strict";

    $(document).ready(function () {
        qodefLucentSpinner.init();
    });

    $(window).on('elementor/frontend/init', function() {
        var isEditMode = Boolean( elementorFrontend.isEditMode() );

        if ( isEditMode ) {
            qodefLucentSpinner.init( isEditMode );
        }
    });

    var qodefLucentSpinner = {
        init: function ( isEditMode ) {
            var $holder = $('#qodef-page-spinner.qodef-layout--lucent'),
                $revHolder = $('#qodef-landing-rev-holder');

            qodefLucentSpinner.windowLoaded = false;

            if ( $holder.length ) {
                if ( isEditMode ) {
                    qodefLucentSpinner.fadeOutLoader( $holder );
                } else {
                    qodefLucentSpinner.animateSpinner( $holder, $revHolder );
                }
            }
        },
        animateSpinner: function ( $holder, $revHolder ) {
            qodefLucentSpinner.windowLoaded = false;

            $( window ).on(
                'load',
                function () {
                qodefLucentSpinner.windowLoaded = true;
            });

            var startAnimation = function() {
                $holder.addClass('qodef--init');

                setTimeout( function () {
                    $holder.addClass('qodef--glow');

                    setTimeout( function () {
                        $holder.addClass('qodef--animate');

                        setTimeout( function () {
                            if ( qodefLucentSpinner.windowLoaded ) {
                                $holder.addClass('qodef--end');

                                setTimeout( function () {
                                    qodefLucentSpinner.fadeOutLoader( $holder );
                                    qodefCore.body.addClass('qodef--preloder-end');

                                    if ( $revHolder.length ) {
                                        $revHolder.find('rs-module').revstart();
                                    }
                                }, 1000);
                            } else {
                                var $interval = setInterval( function() {
                                    if ( qodefLucentSpinner.windowLoaded ) {
                                        clearInterval($interval);
                                        $holder.addClass('qodef--end');

                                        setTimeout( function () {
                                            qodefLucentSpinner.fadeOutLoader( $holder );
                                            $('body').addClass('qodef--preloder-end');

                                            if ( $revHolder.length ) {
                                                $revHolder.find('rs-module').revstart();
                                            }
                                        }, 1000);
                                    }
                                }, 100);
                            }
                        }, 4000)
                    }, 2000)
                }, 2000)
            };

            startAnimation();
        },
        fadeOutLoader: function ($holder, speed, delay, easing) {
            speed = speed ? speed : 800;
            delay = delay ? delay : 0;
            easing = easing ? easing : 'swing';

            if ($holder.length) {
                $holder.delay(delay).fadeOut(speed, easing);
                $(window).on('bind', 'pageshow', function (event) {
                    if (event.originalEvent.persisted) {
                        $holder.fadeOut(speed, easing);

                        setTimeout( function() {
                            $holder.removeClass();
                        }, 1000);
                    }
                });
            }
        }
    };

})(jQuery);

(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefProgressBarSpinner.init();
	});
	
	var qodefProgressBarSpinner = {
		percentNumber: 0,
		init: function () {
			this.holder = $('#qodef-page-spinner.qodef-layout--progress-bar');
			
			if (this.holder.length) {
				qodefProgressBarSpinner.animateSpinner(this.holder);
			}
		},
		animateSpinner: function ($holder) {
			
			var $numberHolder = $holder.find('.qodef-m-spinner-number-label'),
				$spinnerLine = $holder.find('.qodef-m-spinner-line-front'),
				numberIntervalFastest,
				windowLoaded = false;
			
			$spinnerLine.animate({'width': '100%'}, 10000, 'linear');
			
			var numberInterval = setInterval(function () {
				qodefProgressBarSpinner.animatePercent($numberHolder, qodefProgressBarSpinner.percentNumber);
			
				if (windowLoaded) {
					clearInterval(numberInterval);
				}
			}, 100);
			
			$(window).on('load', function () {
				windowLoaded = true;
				
				numberIntervalFastest = setInterval(function () {
					if (qodefProgressBarSpinner.percentNumber >= 100) {
						clearInterval(numberIntervalFastest);
						$spinnerLine.stop().animate({'width': '100%'}, 500);
						
						setTimeout(function () {
							$holder.addClass('qodef--finished');
							
							setTimeout(function () {
								qodefProgressBarSpinner.fadeOutLoader($holder);
							}, 1000);
						}, 600);
					} else {
						qodefProgressBarSpinner.animatePercent($numberHolder, qodefProgressBarSpinner.percentNumber);
					}
				}, 6);
			});
		},
		animatePercent: function ($numberHolder, percentNumber) {
			if (percentNumber < 100) {
				percentNumber += 5;
				$numberHolder.text(percentNumber);
				
				qodefProgressBarSpinner.percentNumber = percentNumber;
			}
		},
		fadeOutLoader: function ($holder, speed, delay, easing) {
			speed = speed ? speed : 600;
			delay = delay ? delay : 0;
			easing = easing ? easing : 'swing';
			
			$holder.delay(delay).fadeOut(speed, easing);
			
			$(window).on('bind', 'pageshow', function (event) {
				if (event.originalEvent.persisted) {
					$holder.fadeOut(speed, easing);
				}
			});
		}
	};
	
})(jQuery);
(function ($) {

	"use strict";
	
	qodefCore.shortcodes.masterds_core_instagram_list = {};
	
	$(document).ready(function () {
		qodefInstagram.init();
	});
	
	var qodefInstagram = {
		init: function () {
			this.holder = $('.sbi.qodef-instagram-swiper-container');
			
			if (this.holder.length) {
				this.holder.each(function () {
					var $thisHolder = $(this),
						sliderOptions = $thisHolder.parent().attr('data-options'),
						$instagramImage = $thisHolder.find('.sbi_item.sbi_type_image'),
						$imageHolder = $thisHolder.find('#sbi_images');
					
					$thisHolder.attr('data-options', sliderOptions);
					
					$imageHolder.addClass('swiper-wrapper');
					
					if ($instagramImage.length) {
						$instagramImage.each(function () {
							$(this).addClass('qodef-e qodef-image-wrapper swiper-slide');
						});
					}
					
					if (typeof qodef.qodefSwiper === 'object') {
						qodef.qodefSwiper.init($thisHolder);
					}
				});
			}
		},
	};
	
	qodefCore.shortcodes.masterds_core_instagram_list.qodefInstagram = qodefInstagram;
	qodefCore.shortcodes.masterds_core_instagram_list.qodefSwiper = qodef.qodefSwiper;
	
})(jQuery);

(function ($) {
    "use strict";
    
	qodefCore.shortcodes.lucent_core_product_categories_list = {};
	qodefCore.shortcodes.lucent_core_product_categories_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.lucent_core_product_categories_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);
(function ($) {
	"use strict";
	
	var shortcode = 'lucent_core_product_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}
	
})(jQuery);
(function($) {
    "use strict";

    /*
     **	Re-init scripts on gallery loaded
     */
	$(document).on('yith_wccl_product_gallery_loaded', function () {
		
		if (typeof qodefCore.qodefWooMagnificPopup === "function") {
			qodefCore.qodefWooMagnificPopup.init();
		}
	});

})(jQuery);
(function ($) {
	"use strict";

	/*$(document).ready(function () {
	 qodefSideAreaCart.init();
	 });*/

	$(document).ready(function () {
		setTimeout(function(){qodefSideAreaCart.init();},1000);
	});

	var qodefSideAreaCart = {
		init: function () {
			var $holder = $('.qodef-woo-side-area-cart');

			if ($holder.length) {
				$holder.each(function () {
					var $thisHolder = $(this);

					if (qodefCore.windowWidth > 680) {
						qodefSideAreaCart.trigger($thisHolder);
						qodef.body.addClass('qodef-side-cart--initialized');

						qodefCore.body.on('added_to_cart', function () {
							if (!qodef.body.hasClass('qodef-side-cart--initialized')) {
								qodefSideAreaCart.trigger($thisHolder);
							}
						});
					}
				});
			}
		},
		trigger: function ($holder) {
			var $items = $holder.find('.qodef-m-items');

			// Open Side Area
			$('.qodef-woo-side-area-cart').on('click', '.qodef-m-opener', function (e) {
				e.preventDefault();
				e.stopPropagation();

				if (!$holder.hasClass('qodef--opened')) {
					qodefSideAreaCart.openSideArea($holder);
					if ($items.length && typeof qodefCore.qodefPerfectScrollbar === 'object') {
						qodefCore.qodefPerfectScrollbar.init($items);
					}

					$(document).keyup(function (e) {
						if (e.keyCode === 27) {
							qodefSideAreaCart.closeSideArea($holder);
						}
					});
				} else {
					qodefSideAreaCart.closeSideArea($holder);
				}
			});

			$('.qodef-woo-side-area-cart').on('click', '.qodef-m-close', function (e) {
				e.preventDefault();
				qodefSideAreaCart.closeSideArea($holder);
			});
		},
		openSideArea: function ($holder) {
			qodefCore.qodefScroll.disable();

			$holder.addClass('qodef--opened');
			$('#qodef-page-wrapper').prepend('<div class="qodef-woo-side-area-cart-cover"/>');

			$('.qodef-woo-side-area-cart-cover').on('click', function (e) {
				e.preventDefault();

				qodefSideAreaCart.closeSideArea($holder);
			});
		},
		closeSideArea: function ($holder) {
			if ($holder.hasClass('qodef--opened')) {
				qodefCore.qodefScroll.enable();

				$holder.removeClass('qodef--opened');
				$('.qodef-woo-side-area-cart-cover').remove();
			}
		}
	};

	$( document.body ).on( 'removed_from_cart', function() {
		/* initialize Cart function again after woo ajax */
		setTimeout(function(){
			qodefSideAreaCart.init();
			console.log('reinit');
		},500);
	});

})(jQuery);

(function ($) {
	"use strict";
	
	qodefCore.shortcodes.lucent_core_clients_list = {};
	qodefCore.shortcodes.lucent_core_clients_list.qodefSwiper = qodef.qodefSwiper;
})(jQuery);
(function ($) {
	"use strict";
	
	var shortcode = 'lucent_core_portfolio_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}

	$(document).ready(function () {
		qodefPortfolioList.init();
	});

	var qodefPortfolioList = {
		init: function () {
			this.holder = $('.qodef-portfolio-list');

			if ( this.holder.length ) {
				this.holder.each( function () {
					var $thisHolder = $(this);

					qodefPortfolioList.linkHover( $thisHolder );
				});
			}
		},
		linkHover: function ( $holder ) {
			var $item = $holder.find('article.portfolio-item');

			$item.each( function() {
				var $thisItem = $(this),
					$itemImage = $thisItem.find('.qodef-e-image'),
					$titleLink = $thisItem.find('.qodef-e-title-link');

				$itemImage.on('mouseenter', function() {
					$itemImage.closest('article.portfolio-item').addClass('qodef--active');
				});

				$titleLink.on('mouseenter', function() {
					$titleLink.closest('article.portfolio-item').addClass('qodef--active');
				});

				$itemImage.on('mouseleave', function() {
					$itemImage.closest('article.portfolio-item').removeClass('qodef--active');
				});

				$titleLink.on('mouseleave', function() {
					$titleLink.closest('article.portfolio-item').removeClass('qodef--active');
				});
			})
		},
	}
	
})(jQuery);
(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.lucent_core_store_list = {};

	$( document ).ready(
		function () {
			qodefInitGoogleMapStoreItems.init();
			qodefStoreListSpinnerPosition.init();
		}
	);

	$( window ).on(
		'load',
		function () {
			qodefStoreSelect2.init();
			qodefStoreListFilter.init();
		}
	);

	$( window ).resize(
		function () {
			qodefStoreListSpinnerPosition.init();
		}
	);

	$( document ).on(
		'lucent_trigger_get_new_posts',
		function ( e, $holder, response, nextPage ) {
			if ( $holder.hasClass( 'qodef-store-list' ) ) {
				qodefStoreFilterReinit.init( $holder, response, nextPage );
			}
		}
	);

	var qodefStoreListSpinnerPosition = {
		init: function () {
			var $store = $( '.qodef-store-list' );

			if ( $store.length ) {
				$store.each(
					function () {
						var $spinner     = $( this ).find( '.qodef-spinner-holder' );
						var $itemsHolder = $( this ).find( '.qodef-grid-inner' );
						var top          = $itemsHolder.offset().top - $( this ).offset().top;

						$spinner.css( 'top', top );
					}
				);
			}
		}
	};

	var qodefStoreSelect2 = {
		init: function ( settings ) {
			var $select = $( '.qodef-store-list .qodef-m--is-select2 select' );
			var $holder = [];

			$select.each(
				function () {
					$holder.push(
						{
							holder: $( this ),
							options: {},
						}
					);
				}
			);

			// allow overriding the default config
			$.extend( $holder, settings );

			if ( typeof $holder === 'object' ) {
				$.each(
					$holder,
					function ( key, value ) {
						qodefStoreSelect2.createSelect2( value.holder, value.options );
					}
				);
			}
		},
		createSelect2: function ( $holder, options ) {
			if ( typeof $holder.select2 === 'function' ) {
				$holder.select2( options );
			}
		}
	};

	var qodefStoreListFilter = {
		init: function () {
			var $holder = $( '.qodef-store-list .qodef-m-filter-holder' );

			if ( $holder.length ) {
				$holder.each(
					function () {
						var $thisHolder    = $( this ),
							$thisStoreList = $thisHolder.parents( '.qodef-store-list' ),
							$fields        = [];

						// filter by attributes
						$fields.$select2Fields        = $holder.find( '.qodef-m--is-select2' );
						$fields.select2FieldsExists   = $fields.$select2Fields.length;
						$fields.$inputTextFields      = $holder.find( '.qodef-e-text' );
						$fields.inputTextFieldsExists = $fields.$inputTextFields.length;

						if ( $fields.select2FieldsExists ) {
							$fields.$select2Fields.each(
								function () {
									qodefStoreListFilter.initSelect2Fields( $( this ), $( this ).data( 'type' ) );
								}
							);
						}

						qodefStoreListFilter.search( $thisHolder, $thisStoreList, $fields );
						qodefStoreListFilter.reset( $thisHolder, $fields );
					}
				);
			}
		},
		search: function ( $holder, $list, $fields ) {
			var $searchButton = $holder.find( '.qodef-m-filter--search' ),
				$resetButton  = $holder.find( '.qodef-m-filter--reset' );

			$searchButton.on(
				'click',
				function ( event ) {
					event.preventDefault();

					var options    = $list.data( 'options' ),
						newOptions = {};

					if ( $fields.select2FieldsExists ) {
						$fields.$select2Fields.each(
							function () {
								var select2Type = $( this ).data( 'type' ),
									value       = $( this ).find( 'select' ).data( select2Type );

								if ( typeof value !== 'undefined' && value !== '' ) {
									newOptions[select2Type] = value;
								} else {
									newOptions[select2Type] = '';
								}
							}
						);
					}

					if ( $fields.inputTextFieldsExists ) {
						$fields.$inputTextFields.each(
							function () {
								var inputTextValue = $( this ).find( 'input[type="text"]' ).val();

								if ( inputTextValue !== '' ) {
									newOptions[$( this ).data( 'type' )] = inputTextValue;
								} else {
									newOptions[$( this ).data( 'type' )] = '';
								}
							}
						);
					}

					var additional = qodefStoreListFilter.createAdditionalQuery( newOptions );

					$.each(
						additional,
						function ( key, value ) {
							options[key] = value;
						}
					);

					$list.data( 'options', options );

					qodef.body.trigger(
						'lucent_trigger_load_more',
						[$list, 1]
					);

					$resetButton.addClass( 'qodef-m-filter-is-searched' );
				}
			);
		},
		reset: function ( $holder, $fields ) {
			var $resetButton  = $holder.find( '.qodef-m-filter--reset' ),
				$searchButton = $holder.find( '.qodef-m-filter--search' );

			// init reset functionality
			$resetButton.on(
				'click',
				function ( event ) {
					event.preventDefault();

					if ( $fields.select2FieldsExists ) {
						$fields.$select2Fields.each(
							function () {
								var select2Type = $( this ).data( 'type' );

								qodefStoreListFilter.resetSelect2Field( $( this ), select2Type );
							}
						);
					}

					if ( $fields.inputTextFieldsExists ) {
						$fields.$inputTextFields.each(
							function () {
								$( this ).find( 'input[type="text"]' ).val( '' );
							}
						);
					}

					if ( $resetButton.hasClass( 'qodef-m-filter-is-searched' ) ) {
						$resetButton.removeClass( 'qodef-m-filter-is-searched' );

						$searchButton.trigger( 'click' );
					}
				}
			);
		},
		initSelect2Fields: function ( $selectElement, paramName ) {
			var $select2Field = $selectElement.find( 'select' );

			if ( $select2Field.length ) {
				$select2Field.select2().on(
					'select2:select',
					function ( event ) {
						var $selectedElement = $( event.currentTarget ),
							selectVal        = $selectedElement.val();

						$selectedElement.data( paramName, selectVal );
					}
				);
			}
		},
		resetSelect2Field: function ( $selectElement, selectParam ) {
			var $select2Field = $selectElement.find( 'select' );

			$select2Field.val( '' ).trigger( 'change' );
			$select2Field.data( selectParam, '' );
		},
		createAdditionalQuery: function ( newOptions ) {
			var addQuery = {};
			var i        = 0;

			addQuery.additional_query_args           = {};
			addQuery.additional_query_args.tax_query = [];

			if ( typeof newOptions === 'object' ) {
				$.each(
					newOptions,
					function ( key, value ) {
						switch (key) {
							case 'order_by':
								addQuery.orderby = newOptions.order_by;
								break;
							case 'category':
							case 'tag':
							case 'location':
								if ( value !== '' ) {
									if ( value.indexOf( ',' ) !== -1 ) {
										value = value.split( ',' );
									}
									addQuery.additional_query_args.tax_query[i]          = {};
									addQuery.additional_query_args.tax_query[i].taxonomy = 'stores-' + key;
									addQuery.additional_query_args.tax_query[i].field    = 'slug';
									addQuery.additional_query_args.tax_query[i].terms    = value;
									i++;
								}
								break;
							case 'custom_search':
								addQuery.custom_search = value;
								break;
						}
					}
				);

				if ( addQuery.additional_query_args.tax_query.length > 1 ) {
					addQuery.additional_query_args.tax_query['relation'] = 'AND';
				}
			}

			return addQuery;
		},
		triggerClick: function ( placeInputID ) {
			var $placeInput = $( placeInputID ),
				$button     = $placeInput.parents( '.qodef-m-filter-holder' ).find( '.qodef-m-filter--search.qodef-button' );

			if ( $button.length ) {
				$button.trigger( 'click' );
			}
		}
	};

	var qodefStoreFilterReinit = {
		init: function ( $holder, response, nextPage ) {
			var options           = $holder.data( 'options' ),
				$paginationHolder = $holder.find( '.qodef-m-pagination' );

			// if filter clicked - adjust pagination
			if ( nextPage == 1 ) {
				options.max_pages_num = response.max_num_pages;
				$holder.data( 'options', options );

				if ( $paginationHolder.length ) {
					$paginationHolder.remove();
				}

				$holder.append( response.pagination_html );

				qodef.qodefPagination.init();
			}

			if ( $holder.hasClass( 'qodef--with-map' ) && typeof window.qodefGoogleMap !== 'undefined' ) {
				console.log(response);
				var addresses = response.addresses.addresses;

				if ( typeof nextPage !== 'undefined' && nextPage !== '' ) {
					qodefMapsVariables.multiple.addresses = addresses;

					window.qodefGoogleMap.init(
						$( '#qodef-multiple-map-holder' ),
						{
							selectorIsID: true,
							multipleTrigger: true,
						}
					);
				} else {
					var adjustAddresses                   = qodefMapsVariables.multiple.addresses.concat( addresses );
					qodefMapsVariables.multiple.addresses = adjustAddresses;

					window.qodefGoogleMap.init(
						$( '#qodef-multiple-map-holder' ),
						{
							selectorIsID: true,
							multipleTrigger: true,
						}
					);
				}

				qodefBindListTitlesAndMap();
			}
		}
	};

	var qodefInitGoogleMapStoreItems = {
		init: function () {
			this.holder = $( '#qodef-multiple-map-holder' );

			if ( this.holder.length && typeof window.qodefGoogleMap !== 'undefined' ) {
				qodefMapsVariables.multiple = this.holder.data( 'addresses' );

				window.qodefGoogleMap.init(
					this.holder,
					{
						selectorIsID: true,
						multipleTrigger: true,
					}
				);
			}
		}
	};

	function qodefBindListTitlesAndMap() {
		var $itemsList = $( '.qodef-map-list-holder' );

		if ( $itemsList.length ) {
			$itemsList.each(
				function () {
					var $listItems = $( this ).find( 'article' ),
						$map       = $( this ).find( '.qodef-map' );

					if ( $map.length ) {
						$listItems.each(
							function () {
								// init hover
								var $listItem = $( this );

								if ( ! $listItem.hasClass( 'qodef-init' ) ) {
									$listItem.on(
										'mouseenter',
										function () {
											var itemId                 = $listItem.data( 'id' ),
												$inactiveMarkersHolder = $( '.qodef-map-marker-holder:not(.qodef-map-active)' ),
												$clusterMarkersHolder  = $( '.qodef-cluster-marker' );

											if ( $inactiveMarkersHolder.length ) {
												$inactiveMarkersHolder.removeClass( 'qodef-active' );
												$( '#' + itemId + '.qodef-map-marker-holder' ).addClass( 'qodef-active' );
											}

											if ( $clusterMarkersHolder.length ) {
												$clusterMarkersHolder.each(
													function () {
														var $thisClusterMarker    = $( this ),
															clusterMarkersItemIds = $thisClusterMarker.data( 'item-ids' );

														if ( clusterMarkersItemIds !== undefined && clusterMarkersItemIds.includes( itemId.toString() ) ) {
															$thisClusterMarker.addClass( 'qodef-active' );
														}
													}
												);
											}
										}
									).on(
										'mouseleave',
										function () {
											var $markersHolder        = $( '.qodef-map-marker-holder' ),
												$clusterMarkersHolder = $( '.qodef-cluster-marker' );

											if ( $markersHolder.length ) {
												$markersHolder.each(
													function () {
														var $thisMapHolder = $( this );

														if ( ! $thisMapHolder.hasClass( 'qodef-map-active' ) ) {
															$thisMapHolder.removeClass( 'qodef-active' );
														}
													}
												);
											}

											if ( $clusterMarkersHolder.length ) {
												$clusterMarkersHolder.removeClass( 'qodef-active' );
											}
										}
									);

									$listItem.addClass( 'qodef-init' );
								}
							}
						);
					}
				}
			);
		}
	}

	qodefCore.shortcodes.lucent_core_store_list.qodefInitGoogleMapStoreItems  = qodefInitGoogleMapStoreItems;
	qodefCore.shortcodes.lucent_core_store_list.qodefStoreSelect2             = qodefStoreSelect2;
	qodefCore.shortcodes.lucent_core_store_list.qodefStoreListFilter          = qodefStoreListFilter;
	qodefCore.shortcodes.lucent_core_store_list.qodefStoreListSpinnerPosition = qodefStoreListSpinnerPosition;

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes.lucent_core_store_list[key] = value;
			}
		);
	}

})( jQuery );

(function ($) {
	"use strict";
	
	var shortcode = 'lucent_core_team_list';
	
	qodefCore.shortcodes[shortcode] = {};
	
	if (typeof qodefCore.listShortcodesScripts === 'object') {
		$.each(qodefCore.listShortcodesScripts, function (key, value) {
			qodefCore.shortcodes[shortcode][key] = value;
		});
	}
	
})(jQuery);
(function ($) {
    "use strict";
	qodefCore.shortcodes.lucent_core_testimonials_list = {};
	qodefCore.shortcodes.lucent_core_testimonials_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);
(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefInfoFollow.init();
	});
	
	$(document).on('lucent_trigger_get_new_posts', function () {
		qodefInfoFollow.init();
	});
	
	var qodefInfoFollow = {
		init: function () {
			var $gallery = $('.qodef-hover-animation--follow');
			
			if ($gallery.length) {
				qodefCore.body.append('<div class="qodef-follow-info-holder"><div class="qodef-follow-info-inner"><span class="qodef-follow-info-category"></span><br/><span class="qodef-follow-info-title"></span></div></div>');
				
				var $followInfoHolder = $('.qodef-follow-info-holder'),
					$followInfoCategory = $followInfoHolder.find('.qodef-follow-info-category'),
					$followInfoTitle = $followInfoHolder.find('.qodef-follow-info-title');
				
				$gallery.each(function () {
					$gallery.find('.qodef-e-inner').each(function () {
						var $thisItem = $(this);
						
						//info element position
						$thisItem.on('mousemove', function (e) {
                            if(e.clientX + 20 + $followInfoHolder.width() > qodefCore.windowWidth){
                                $followInfoHolder.addClass('qodef-right');
                            }else{
                                $followInfoHolder.removeClass('qodef-right');
                            }

							$followInfoHolder.css({
								top: e.clientY + 20,
								left: e.clientX + 20
							});
						});
						
						//show/hide info element
						$thisItem.on('mouseenter', function () {
							var $thisItemTitle = $(this).find('.qodef-e-title'),
								$thisItemCategory = $(this).find('.qodef-e-info-category');
							
							if ($thisItemTitle.length) {
								$followInfoTitle.html($thisItemTitle.clone());
							}
							
							if ($thisItemCategory.length) {
								$followInfoCategory.html($thisItemCategory.html());
							}
							
							if (!$followInfoHolder.hasClass('qodef-is-active')) {
								$followInfoHolder.addClass('qodef-is-active');
							}
						}).on('mouseleave', function () {
							if ($followInfoHolder.hasClass('qodef-is-active')) {
								$followInfoHolder.removeClass('qodef-is-active');
							}
						});
					});
				});
			}
		}
	};
	
	qodefCore.shortcodes.lucent_core_portfolio_list.qodefInfoFollow = qodefInfoFollow;
	
})(jQuery);
(function ($) {
	"use strict";
	
	$(document).ready(function () {
		qodefHoverDir.init();
	});
	
	$(document).on('lucent_trigger_get_new_posts', function () {
		qodefHoverDir.init();
	});
	
	var qodefHoverDir = {
		init: function () {
			var $gallery = $('.qodef-hover-animation--direction-aware');
			
			if ($gallery.length) {
				$gallery.each(function () {
					var $this = $(this);
					$this.find('article').each(function () {
						$(this).hoverdir({
							hoverElem: 'div.qodef-e-content',
							speed: 330,
							hoverDelay: 35,
							easing: 'ease'
						});
					});
				});
			}
		}
	};
	
	qodefCore.shortcodes.lucent_core_portfolio_list.qodefHoverDir = qodefHoverDir;
	
})(jQuery);