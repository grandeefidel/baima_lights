<?php

define( 'LUCENT_CORE_VERSION', '1.0.2' );
define( 'LUCENT_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'LUCENT_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'LUCENT_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'LUCENT_CORE_ASSETS_PATH', LUCENT_CORE_ABS_PATH . '/assets' );
define( 'LUCENT_CORE_ASSETS_URL_PATH', LUCENT_CORE_URL_PATH . 'assets' );
define( 'LUCENT_CORE_INC_PATH', LUCENT_CORE_ABS_PATH . '/inc' );
define( 'LUCENT_CORE_INC_URL_PATH', LUCENT_CORE_URL_PATH . 'inc' );
define( 'LUCENT_CORE_CPT_PATH', LUCENT_CORE_INC_PATH . '/post-types' );
define( 'LUCENT_CORE_CPT_URL_PATH', LUCENT_CORE_INC_URL_PATH . '/post-types' );
define( 'LUCENT_CORE_SHORTCODES_PATH', LUCENT_CORE_INC_PATH . '/shortcodes' );
define( 'LUCENT_CORE_SHORTCODES_URL_PATH', LUCENT_CORE_INC_URL_PATH . '/shortcodes' );
define( 'LUCENT_CORE_PLUGINS_PATH', LUCENT_CORE_INC_PATH . '/plugins' );
define( 'LUCENT_CORE_PLUGINS_URL_PATH', LUCENT_CORE_INC_URL_PATH . '/plugins' );
define( 'LUCENT_CORE_HEADER_LAYOUTS_PATH', LUCENT_CORE_INC_PATH . '/header/layouts' );
define( 'LUCENT_CORE_HEADER_LAYOUTS_URL_PATH', LUCENT_CORE_INC_URL_PATH . '/header/layouts' );
define( 'LUCENT_CORE_HEADER_ASSETS_PATH', LUCENT_CORE_INC_PATH . '/header/assets' );
define( 'LUCENT_CORE_HEADER_ASSETS_URL_PATH', LUCENT_CORE_INC_URL_PATH . '/header/assets' );
define( 'LUCENT_CORE_MOBILE_HEADER_LAYOUTS_PATH', LUCENT_CORE_INC_PATH . '/mobile-header/layouts' );
define( 'LUCENT_CORE_MOBILE_HEADER_LAYOUTS_URL_PATH', LUCENT_CORE_INC_URL_PATH . '/mobile-header/layouts' );

define( 'LUCENT_CORE_MENU_NAME', 'lucent_core_menu' );
define( 'LUCENT_CORE_OPTIONS_NAME', 'lucent_core_options' );

define( 'LUCENT_CORE_PROFILE_SLUG', 'mikado' );
