<div class="qodef-m-social-login qodef--google">
	<button type="submit" class="qodef-m-social-login-btn" data-social="google"><?php echo qode_framework_icons()->render_icon( 'social_googleplus', 'elegant-icons' ); ?></button>
</div>