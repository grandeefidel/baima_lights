<?php

require_once LUCENT_MEMBERSHIP_INC_PATH . '/general/register-template.php';
include_once LUCENT_MEMBERSHIP_INC_PATH . '/general/helper.php';